<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<core:CityModel 
xmlns:core="http://www.opengis.net/citygml/2.0"
xmlns:gen="http://www.opengis.net/citygml/generics/2.0"
xmlns:bldg="http://www.opengis.net/citygml/building/2.0"
xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"
xmlns:app="http://www.opengis.net/citygml/appearance/2.0"
xmlns:dem="http://www.opengis.net/citygml/relief/2.0"
xmlns:gml="http://www.opengis.net/gml"
xmlns:xlink="http://www.w3.org/1999/xlink"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd  http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd " gml:id="BUD3D_2476_M-34-62-B-b-1-2">
  <gml:boundedBy>
    <gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:PL-KRON86-NH" srsDimension="3">
      <gml:lowerCorner>493436.49 271699.05 276.90</gml:lowerCorner>
      <gml:upperCorner>495004.99 272705.01 345.99</gml:upperCorner>
    </gml:Envelope>
  </gml:boundedBy>
<core:cityObjectMember>
<bldg:Building gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403">
<gen:stringAttribute name="buildingId">
<gen:value>2A522112-FC32-62E0-E053-CA2BA8C0E403</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="przestNazw">
<gen:value>PL.PZGiK.238.BDOT10k</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="wersjaId">
<gen:value>2015-02-10T00:00:00</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="zrodloDach">
<gen:value>ALS_II</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="aktZrodla">
<gen:value>2011</gen:value>
</gen:stringAttribute>
<bldg:roofType>1130</bldg:roofType>
<bldg:lod2Solid>
<gml:Solid>
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_GS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_3_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_4_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_5_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_6_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_7_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_8_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_9_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_10_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_11_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_3_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_4_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_5_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_6_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_7_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_8_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_9_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_10_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_11_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_12_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_13_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_14_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_15_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_16_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_17_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_18_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_19_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_20_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_21_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_22_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_23_PG"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_GS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_GS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494290.33 271868.00 287.34</gml:pos>
<gml:pos srsDimension="3">494230.71 271824.01 287.34</gml:pos>
<gml:pos srsDimension="3">494223.22 271834.37 287.34</gml:pos>
<gml:pos srsDimension="3">494282.83 271878.29 287.34</gml:pos>
<gml:pos srsDimension="3">494290.33 271868.00 287.34</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494230.71 271824.01 287.34</gml:pos>
<gml:pos srsDimension="3">494290.33 271868.00 287.34</gml:pos>
<gml:pos srsDimension="3">494290.33 271868.00 290.33</gml:pos>
<gml:pos srsDimension="3">494280.65 271860.86 290.35</gml:pos>
<gml:pos srsDimension="3">494280.65 271860.86 290.81</gml:pos>
<gml:pos srsDimension="3">494270.83 271853.61 290.84</gml:pos>
<gml:pos srsDimension="3">494270.83 271853.61 291.28</gml:pos>
<gml:pos srsDimension="3">494260.89 271846.27 291.30</gml:pos>
<gml:pos srsDimension="3">494260.89 271846.27 291.51</gml:pos>
<gml:pos srsDimension="3">494250.82 271838.85 291.51</gml:pos>
<gml:pos srsDimension="3">494250.82 271838.85 291.78</gml:pos>
<gml:pos srsDimension="3">494230.71 271824.01 291.74</gml:pos>
<gml:pos srsDimension="3">494230.71 271824.01 287.34</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494223.22 271834.37 287.34</gml:pos>
<gml:pos srsDimension="3">494230.71 271824.01 287.34</gml:pos>
<gml:pos srsDimension="3">494230.71 271824.01 291.74</gml:pos>
<gml:pos srsDimension="3">494227.21 271828.85 292.19</gml:pos>
<gml:pos srsDimension="3">494226.91 271829.27 292.67</gml:pos>
<gml:pos srsDimension="3">494226.71 271829.55 292.44</gml:pos>
<gml:pos srsDimension="3">494223.22 271834.37 292.02</gml:pos>
<gml:pos srsDimension="3">494223.22 271834.37 287.34</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494282.83 271878.29 287.34</gml:pos>
<gml:pos srsDimension="3">494223.22 271834.37 287.34</gml:pos>
<gml:pos srsDimension="3">494223.22 271834.37 292.02</gml:pos>
<gml:pos srsDimension="3">494233.29 271841.79 291.95</gml:pos>
<gml:pos srsDimension="3">494233.29 271841.79 291.57</gml:pos>
<gml:pos srsDimension="3">494243.27 271849.15 291.57</gml:pos>
<gml:pos srsDimension="3">494243.27 271849.15 291.13</gml:pos>
<gml:pos srsDimension="3">494253.16 271856.43 291.13</gml:pos>
<gml:pos srsDimension="3">494253.16 271856.43 290.79</gml:pos>
<gml:pos srsDimension="3">494263.05 271863.72 290.80</gml:pos>
<gml:pos srsDimension="3">494263.05 271863.72 290.33</gml:pos>
<gml:pos srsDimension="3">494272.99 271871.04 290.37</gml:pos>
<gml:pos srsDimension="3">494272.99 271871.04 290.00</gml:pos>
<gml:pos srsDimension="3">494282.83 271878.29 290.03</gml:pos>
<gml:pos srsDimension="3">494282.83 271878.29 287.34</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_4">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_4_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494290.33 271868.00 287.34</gml:pos>
<gml:pos srsDimension="3">494282.83 271878.29 287.34</gml:pos>
<gml:pos srsDimension="3">494282.83 271878.29 290.03</gml:pos>
<gml:pos srsDimension="3">494286.20 271873.67 290.30</gml:pos>
<gml:pos srsDimension="3">494286.47 271873.29 290.98</gml:pos>
<gml:pos srsDimension="3">494286.80 271872.84 290.69</gml:pos>
<gml:pos srsDimension="3">494290.33 271868.00 290.33</gml:pos>
<gml:pos srsDimension="3">494290.33 271868.00 287.34</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_5">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_5_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494236.96 271836.76 292.37</gml:pos>
<gml:pos srsDimension="3">494236.79 271837.00 292.10</gml:pos>
<gml:pos srsDimension="3">494233.29 271841.79 291.57</gml:pos>
<gml:pos srsDimension="3">494233.29 271841.79 291.95</gml:pos>
<gml:pos srsDimension="3">494236.79 271837.00 292.36</gml:pos>
<gml:pos srsDimension="3">494236.96 271836.76 292.37</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_6">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_6_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494237.47 271836.06 292.18</gml:pos>
<gml:pos srsDimension="3">494237.33 271836.25 292.20</gml:pos>
<gml:pos srsDimension="3">494237.16 271836.49 292.62</gml:pos>
<gml:pos srsDimension="3">494237.33 271836.25 292.38</gml:pos>
<gml:pos srsDimension="3">494237.47 271836.06 292.18</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_7">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_7_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494250.82 271838.85 291.51</gml:pos>
<gml:pos srsDimension="3">494247.33 271843.62 291.92</gml:pos>
<gml:pos srsDimension="3">494247.19 271843.80 292.03</gml:pos>
<gml:pos srsDimension="3">494247.07 271843.97 292.10</gml:pos>
<gml:pos srsDimension="3">494246.81 271844.32 291.58</gml:pos>
<gml:pos srsDimension="3">494243.27 271849.15 291.13</gml:pos>
<gml:pos srsDimension="3">494243.27 271849.15 291.57</gml:pos>
<gml:pos srsDimension="3">494246.81 271844.32 292.04</gml:pos>
<gml:pos srsDimension="3">494247.07 271843.97 292.40</gml:pos>
<gml:pos srsDimension="3">494247.19 271843.80 292.56</gml:pos>
<gml:pos srsDimension="3">494247.33 271843.62 292.24</gml:pos>
<gml:pos srsDimension="3">494250.82 271838.85 291.78</gml:pos>
<gml:pos srsDimension="3">494250.82 271838.85 291.51</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_8">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_8_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494260.89 271846.27 291.30</gml:pos>
<gml:pos srsDimension="3">494257.41 271850.84 291.66</gml:pos>
<gml:pos srsDimension="3">494257.28 271851.00 291.74</gml:pos>
<gml:pos srsDimension="3">494257.10 271851.24 291.86</gml:pos>
<gml:pos srsDimension="3">494256.81 271851.63 291.12</gml:pos>
<gml:pos srsDimension="3">494253.16 271856.43 290.79</gml:pos>
<gml:pos srsDimension="3">494253.16 271856.43 291.13</gml:pos>
<gml:pos srsDimension="3">494256.81 271851.63 291.58</gml:pos>
<gml:pos srsDimension="3">494257.10 271851.24 292.11</gml:pos>
<gml:pos srsDimension="3">494257.28 271851.00 291.96</gml:pos>
<gml:pos srsDimension="3">494257.41 271850.84 291.92</gml:pos>
<gml:pos srsDimension="3">494260.89 271846.27 291.51</gml:pos>
<gml:pos srsDimension="3">494260.89 271846.27 291.30</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_9">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_9_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494270.83 271853.61 290.84</gml:pos>
<gml:pos srsDimension="3">494267.47 271857.98 291.15</gml:pos>
<gml:pos srsDimension="3">494267.29 271858.22 291.43</gml:pos>
<gml:pos srsDimension="3">494267.15 271858.39 291.18</gml:pos>
<gml:pos srsDimension="3">494267.15 271858.39 291.70</gml:pos>
<gml:pos srsDimension="3">494267.29 271858.22 291.67</gml:pos>
<gml:pos srsDimension="3">494267.47 271857.98 291.65</gml:pos>
<gml:pos srsDimension="3">494270.83 271853.61 291.28</gml:pos>
<gml:pos srsDimension="3">494270.83 271853.61 290.84</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_10">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_10_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494280.65 271860.86 290.35</gml:pos>
<gml:pos srsDimension="3">494277.32 271865.29 290.69</gml:pos>
<gml:pos srsDimension="3">494276.99 271865.72 290.99</gml:pos>
<gml:pos srsDimension="3">494276.80 271865.97 290.55</gml:pos>
<gml:pos srsDimension="3">494276.68 271866.14 290.28</gml:pos>
<gml:pos srsDimension="3">494276.48 271866.41 290.28</gml:pos>
<gml:pos srsDimension="3">494272.99 271871.04 290.00</gml:pos>
<gml:pos srsDimension="3">494272.99 271871.04 290.37</gml:pos>
<gml:pos srsDimension="3">494276.48 271866.41 290.72</gml:pos>
<gml:pos srsDimension="3">494276.68 271866.14 291.15</gml:pos>
<gml:pos srsDimension="3">494276.80 271865.97 291.42</gml:pos>
<gml:pos srsDimension="3">494276.99 271865.72 291.16</gml:pos>
<gml:pos srsDimension="3">494277.32 271865.29 291.12</gml:pos>
<gml:pos srsDimension="3">494280.65 271860.86 290.81</gml:pos>
<gml:pos srsDimension="3">494280.65 271860.86 290.35</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_11">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_WS_11_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494267.15 271858.39 291.18</gml:pos>
<gml:pos srsDimension="3">494266.92 271858.68 290.71</gml:pos>
<gml:pos srsDimension="3">494266.62 271859.08 290.69</gml:pos>
<gml:pos srsDimension="3">494263.05 271863.72 290.33</gml:pos>
<gml:pos srsDimension="3">494263.05 271863.72 290.80</gml:pos>
<gml:pos srsDimension="3">494266.62 271859.08 291.13</gml:pos>
<gml:pos srsDimension="3">494266.92 271858.68 291.87</gml:pos>
<gml:pos srsDimension="3">494267.15 271858.39 291.70</gml:pos>
<gml:pos srsDimension="3">494267.15 271858.39 291.18</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494233.29 271841.79 291.95</gml:pos>
<gml:pos srsDimension="3">494223.22 271834.37 292.02</gml:pos>
<gml:pos srsDimension="3">494226.71 271829.55 292.44</gml:pos>
<gml:pos srsDimension="3">494236.96 271836.76 292.37</gml:pos>
<gml:pos srsDimension="3">494236.79 271837.00 292.36</gml:pos>
<gml:pos srsDimension="3">494233.29 271841.79 291.95</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494226.91 271829.27 292.67</gml:pos>
<gml:pos srsDimension="3">494227.21 271828.85 292.19</gml:pos>
<gml:pos srsDimension="3">494237.47 271836.06 292.18</gml:pos>
<gml:pos srsDimension="3">494237.33 271836.25 292.38</gml:pos>
<gml:pos srsDimension="3">494237.16 271836.49 292.62</gml:pos>
<gml:pos srsDimension="3">494226.91 271829.27 292.67</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494247.07 271843.97 292.40</gml:pos>
<gml:pos srsDimension="3">494246.81 271844.32 292.04</gml:pos>
<gml:pos srsDimension="3">494236.79 271837.00 292.10</gml:pos>
<gml:pos srsDimension="3">494236.96 271836.76 292.37</gml:pos>
<gml:pos srsDimension="3">494237.16 271836.49 292.62</gml:pos>
<gml:pos srsDimension="3">494247.19 271843.80 292.56</gml:pos>
<gml:pos srsDimension="3">494247.07 271843.97 292.40</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_4">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_4_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494256.81 271851.63 291.58</gml:pos>
<gml:pos srsDimension="3">494253.16 271856.43 291.13</gml:pos>
<gml:pos srsDimension="3">494243.27 271849.15 291.13</gml:pos>
<gml:pos srsDimension="3">494246.81 271844.32 291.58</gml:pos>
<gml:pos srsDimension="3">494256.81 271851.63 291.58</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_5">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_5_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494260.89 271846.27 291.30</gml:pos>
<gml:pos srsDimension="3">494270.83 271853.61 291.28</gml:pos>
<gml:pos srsDimension="3">494267.47 271857.98 291.65</gml:pos>
<gml:pos srsDimension="3">494267.29 271858.22 291.67</gml:pos>
<gml:pos srsDimension="3">494267.15 271858.39 291.70</gml:pos>
<gml:pos srsDimension="3">494257.41 271850.84 291.66</gml:pos>
<gml:pos srsDimension="3">494260.89 271846.27 291.30</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_6">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_6_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494276.68 271866.14 291.15</gml:pos>
<gml:pos srsDimension="3">494276.48 271866.41 290.72</gml:pos>
<gml:pos srsDimension="3">494266.92 271858.68 290.71</gml:pos>
<gml:pos srsDimension="3">494267.15 271858.39 291.18</gml:pos>
<gml:pos srsDimension="3">494267.29 271858.22 291.43</gml:pos>
<gml:pos srsDimension="3">494276.80 271865.97 291.42</gml:pos>
<gml:pos srsDimension="3">494276.68 271866.14 291.15</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_7">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_7_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494270.83 271853.61 290.84</gml:pos>
<gml:pos srsDimension="3">494280.65 271860.86 290.81</gml:pos>
<gml:pos srsDimension="3">494277.32 271865.29 291.12</gml:pos>
<gml:pos srsDimension="3">494276.99 271865.72 291.16</gml:pos>
<gml:pos srsDimension="3">494267.47 271857.98 291.15</gml:pos>
<gml:pos srsDimension="3">494270.83 271853.61 290.84</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_8">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_8_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494286.20 271873.67 290.30</gml:pos>
<gml:pos srsDimension="3">494282.83 271878.29 290.03</gml:pos>
<gml:pos srsDimension="3">494272.99 271871.04 290.00</gml:pos>
<gml:pos srsDimension="3">494276.48 271866.41 290.28</gml:pos>
<gml:pos srsDimension="3">494276.68 271866.14 290.28</gml:pos>
<gml:pos srsDimension="3">494286.20 271873.67 290.30</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_9">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_9_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494286.47 271873.29 290.98</gml:pos>
<gml:pos srsDimension="3">494286.20 271873.67 290.30</gml:pos>
<gml:pos srsDimension="3">494276.68 271866.14 290.28</gml:pos>
<gml:pos srsDimension="3">494276.80 271865.97 290.55</gml:pos>
<gml:pos srsDimension="3">494276.99 271865.72 290.99</gml:pos>
<gml:pos srsDimension="3">494286.47 271873.29 290.98</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_10">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_10_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494290.33 271868.00 290.33</gml:pos>
<gml:pos srsDimension="3">494286.80 271872.84 290.69</gml:pos>
<gml:pos srsDimension="3">494277.32 271865.29 290.69</gml:pos>
<gml:pos srsDimension="3">494280.65 271860.86 290.35</gml:pos>
<gml:pos srsDimension="3">494290.33 271868.00 290.33</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_11">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_11_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494230.71 271824.01 291.74</gml:pos>
<gml:pos srsDimension="3">494250.82 271838.85 291.78</gml:pos>
<gml:pos srsDimension="3">494247.33 271843.62 292.24</gml:pos>
<gml:pos srsDimension="3">494237.33 271836.25 292.20</gml:pos>
<gml:pos srsDimension="3">494237.47 271836.06 292.18</gml:pos>
<gml:pos srsDimension="3">494227.21 271828.85 292.19</gml:pos>
<gml:pos srsDimension="3">494230.71 271824.01 291.74</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_12">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_12_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494243.27 271849.15 291.57</gml:pos>
<gml:pos srsDimension="3">494233.29 271841.79 291.57</gml:pos>
<gml:pos srsDimension="3">494236.79 271837.00 292.10</gml:pos>
<gml:pos srsDimension="3">494246.81 271844.32 292.04</gml:pos>
<gml:pos srsDimension="3">494243.27 271849.15 291.57</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_13">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_13_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494226.71 271829.55 292.44</gml:pos>
<gml:pos srsDimension="3">494226.91 271829.27 292.67</gml:pos>
<gml:pos srsDimension="3">494237.16 271836.49 292.62</gml:pos>
<gml:pos srsDimension="3">494236.96 271836.76 292.37</gml:pos>
<gml:pos srsDimension="3">494226.71 271829.55 292.44</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_14">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_14_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494266.62 271859.08 291.13</gml:pos>
<gml:pos srsDimension="3">494263.05 271863.72 290.80</gml:pos>
<gml:pos srsDimension="3">494253.16 271856.43 290.79</gml:pos>
<gml:pos srsDimension="3">494256.81 271851.63 291.12</gml:pos>
<gml:pos srsDimension="3">494266.62 271859.08 291.13</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_15">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_15_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494256.81 271851.63 291.58</gml:pos>
<gml:pos srsDimension="3">494246.81 271844.32 291.58</gml:pos>
<gml:pos srsDimension="3">494247.07 271843.97 292.10</gml:pos>
<gml:pos srsDimension="3">494257.10 271851.24 292.11</gml:pos>
<gml:pos srsDimension="3">494256.81 271851.63 291.58</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_16">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_16_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494257.10 271851.24 292.11</gml:pos>
<gml:pos srsDimension="3">494247.07 271843.97 292.10</gml:pos>
<gml:pos srsDimension="3">494247.19 271843.80 292.03</gml:pos>
<gml:pos srsDimension="3">494247.33 271843.62 291.92</gml:pos>
<gml:pos srsDimension="3">494257.28 271851.00 291.96</gml:pos>
<gml:pos srsDimension="3">494257.10 271851.24 292.11</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_17">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_17_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494266.92 271858.68 291.87</gml:pos>
<gml:pos srsDimension="3">494266.62 271859.08 291.13</gml:pos>
<gml:pos srsDimension="3">494256.81 271851.63 291.12</gml:pos>
<gml:pos srsDimension="3">494257.10 271851.24 291.86</gml:pos>
<gml:pos srsDimension="3">494266.92 271858.68 291.87</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_18">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_18_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494276.99 271865.72 291.16</gml:pos>
<gml:pos srsDimension="3">494276.80 271865.97 291.42</gml:pos>
<gml:pos srsDimension="3">494267.29 271858.22 291.43</gml:pos>
<gml:pos srsDimension="3">494267.47 271857.98 291.15</gml:pos>
<gml:pos srsDimension="3">494276.99 271865.72 291.16</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_19">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_19_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494286.80 271872.84 290.69</gml:pos>
<gml:pos srsDimension="3">494286.47 271873.29 290.98</gml:pos>
<gml:pos srsDimension="3">494276.99 271865.72 290.99</gml:pos>
<gml:pos srsDimension="3">494277.32 271865.29 290.69</gml:pos>
<gml:pos srsDimension="3">494286.80 271872.84 290.69</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_20">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_20_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494257.41 271850.84 291.92</gml:pos>
<gml:pos srsDimension="3">494257.28 271851.00 291.96</gml:pos>
<gml:pos srsDimension="3">494247.33 271843.62 291.92</gml:pos>
<gml:pos srsDimension="3">494250.82 271838.85 291.51</gml:pos>
<gml:pos srsDimension="3">494260.89 271846.27 291.51</gml:pos>
<gml:pos srsDimension="3">494257.41 271850.84 291.92</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_21">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_21_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494247.33 271843.62 292.24</gml:pos>
<gml:pos srsDimension="3">494247.19 271843.80 292.56</gml:pos>
<gml:pos srsDimension="3">494237.16 271836.49 292.62</gml:pos>
<gml:pos srsDimension="3">494237.33 271836.25 292.20</gml:pos>
<gml:pos srsDimension="3">494247.33 271843.62 292.24</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_22">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_22_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494266.92 271858.68 291.87</gml:pos>
<gml:pos srsDimension="3">494257.10 271851.24 291.86</gml:pos>
<gml:pos srsDimension="3">494257.28 271851.00 291.74</gml:pos>
<gml:pos srsDimension="3">494257.41 271850.84 291.66</gml:pos>
<gml:pos srsDimension="3">494267.15 271858.39 291.70</gml:pos>
<gml:pos srsDimension="3">494266.92 271858.68 291.87</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_23">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-FC32-62E0-E053-CA2BA8C0E403_RS_23_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494276.48 271866.41 290.72</gml:pos>
<gml:pos srsDimension="3">494272.99 271871.04 290.37</gml:pos>
<gml:pos srsDimension="3">494263.05 271863.72 290.33</gml:pos>
<gml:pos srsDimension="3">494266.62 271859.08 290.69</gml:pos>
<gml:pos srsDimension="3">494266.92 271858.68 290.71</gml:pos>
<gml:pos srsDimension="3">494276.48 271866.41 290.72</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</core:cityObjectMember>
<core:cityObjectMember>
<bldg:Building gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403">
<gen:stringAttribute name="buildingId">
<gen:value>2A522113-0066-62E0-E053-CA2BA8C0E403</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="przestNazw">
<gen:value>PL.PZGiK.238.BDOT10k</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="wersjaId">
<gen:value>2015-02-10T00:00:00</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="zrodloDach">
<gen:value>ALS_II</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="aktZrodla">
<gen:value>2011</gen:value>
</gen:stringAttribute>
<bldg:roofType>1130</bldg:roofType>
<bldg:lod2Solid>
<gml:Solid>
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_GS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_3_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_4_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_5_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_6_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_7_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_8_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_9_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_10_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_11_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_12_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_13_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_14_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_15_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_16_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_17_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_18_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_19_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_20_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_21_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_22_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_23_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_24_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_25_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_26_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_27_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_28_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_29_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_30_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_31_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_32_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_33_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_34_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_35_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_36_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_37_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_38_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_39_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_40_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_41_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_42_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_43_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_44_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_45_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_46_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_47_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_48_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_49_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_50_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_51_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_52_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_53_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_54_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_55_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_56_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_57_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_58_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_59_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_60_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_61_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_62_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_63_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_64_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_65_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_66_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_67_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_3_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_4_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_5_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_6_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_7_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_8_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_9_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_10_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_11_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_12_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_13_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_14_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_15_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_16_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_17_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_18_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_19_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_20_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_21_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_22_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_23_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_24_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_25_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_26_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_27_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_28_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_29_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_30_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_31_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_32_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_33_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_34_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_35_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_36_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_37_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_38_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_39_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_40_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_41_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_42_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_43_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_44_PG"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_GS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_GS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494024.72 272096.10 288.03</gml:pos>
<gml:pos srsDimension="3">494031.22 272081.62 288.03</gml:pos>
<gml:pos srsDimension="3">494010.37 272072.25 288.03</gml:pos>
<gml:pos srsDimension="3">494012.48 272067.56 288.03</gml:pos>
<gml:pos srsDimension="3">493992.65 272058.69 288.03</gml:pos>
<gml:pos srsDimension="3">493990.64 272063.82 288.03</gml:pos>
<gml:pos srsDimension="3">493989.33 272064.16 288.03</gml:pos>
<gml:pos srsDimension="3">493988.28 272064.20 288.03</gml:pos>
<gml:pos srsDimension="3">493986.25 272063.11 288.03</gml:pos>
<gml:pos srsDimension="3">493985.24 272061.85 288.03</gml:pos>
<gml:pos srsDimension="3">493987.51 272056.22 288.03</gml:pos>
<gml:pos srsDimension="3">493979.05 272052.60 288.03</gml:pos>
<gml:pos srsDimension="3">493976.74 272051.30 288.03</gml:pos>
<gml:pos srsDimension="3">493968.20 272047.69 288.03</gml:pos>
<gml:pos srsDimension="3">493966.06 272052.48 288.03</gml:pos>
<gml:pos srsDimension="3">493964.63 272052.77 288.03</gml:pos>
<gml:pos srsDimension="3">493963.41 272052.73 288.03</gml:pos>
<gml:pos srsDimension="3">493963.30 272052.68 288.03</gml:pos>
<gml:pos srsDimension="3">493962.21 272052.19 288.03</gml:pos>
<gml:pos srsDimension="3">493961.19 272051.18 288.03</gml:pos>
<gml:pos srsDimension="3">493960.68 272050.13 288.03</gml:pos>
<gml:pos srsDimension="3">493962.69 272045.21 288.03</gml:pos>
<gml:pos srsDimension="3">493946.08 272038.03 288.03</gml:pos>
<gml:pos srsDimension="3">493935.80 272062.03 288.03</gml:pos>
<gml:pos srsDimension="3">493952.48 272069.23 288.03</gml:pos>
<gml:pos srsDimension="3">493954.49 272064.60 288.03</gml:pos>
<gml:pos srsDimension="3">493955.08 272064.33 288.03</gml:pos>
<gml:pos srsDimension="3">493956.07 272064.24 288.03</gml:pos>
<gml:pos srsDimension="3">493958.81 272065.48 288.03</gml:pos>
<gml:pos srsDimension="3">493959.70 272066.30 288.03</gml:pos>
<gml:pos srsDimension="3">493959.86 272067.09 288.03</gml:pos>
<gml:pos srsDimension="3">493957.95 272071.60 288.03</gml:pos>
<gml:pos srsDimension="3">493977.20 272080.20 288.03</gml:pos>
<gml:pos srsDimension="3">493979.20 272075.21 288.03</gml:pos>
<gml:pos srsDimension="3">493980.87 272075.27 288.03</gml:pos>
<gml:pos srsDimension="3">493982.65 272076.01 288.03</gml:pos>
<gml:pos srsDimension="3">493983.51 272076.43 288.03</gml:pos>
<gml:pos srsDimension="3">493984.42 272077.73 288.03</gml:pos>
<gml:pos srsDimension="3">493982.36 272082.65 288.03</gml:pos>
<gml:pos srsDimension="3">494001.90 272091.59 288.03</gml:pos>
<gml:pos srsDimension="3">494003.82 272087.00 288.03</gml:pos>
<gml:pos srsDimension="3">494024.72 272096.10 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
<gml:interior>
<gml:LinearRing>
<gml:pos srsDimension="3">493946.80 272055.99 288.03</gml:pos>
<gml:pos srsDimension="3">493949.29 272050.15 288.03</gml:pos>
<gml:pos srsDimension="3">493954.99 272052.58 288.03</gml:pos>
<gml:pos srsDimension="3">493952.49 272058.42 288.03</gml:pos>
<gml:pos srsDimension="3">493946.80 272055.99 288.03</gml:pos>
</gml:LinearRing>
</gml:interior>
<gml:interior>
<gml:LinearRing>
<gml:pos srsDimension="3">493979.22 272063.79 288.03</gml:pos>
<gml:pos srsDimension="3">493976.76 272069.40 288.03</gml:pos>
<gml:pos srsDimension="3">493966.90 272065.06 288.03</gml:pos>
<gml:pos srsDimension="3">493969.37 272059.45 288.03</gml:pos>
<gml:pos srsDimension="3">493979.22 272063.79 288.03</gml:pos>
</gml:LinearRing>
</gml:interior>
<gml:interior>
<gml:LinearRing>
<gml:pos srsDimension="3">494005.34 272081.97 288.03</gml:pos>
<gml:pos srsDimension="3">493989.59 272074.97 288.03</gml:pos>
<gml:pos srsDimension="3">493992.10 272069.30 288.03</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 288.03</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 288.03</gml:pos>
</gml:LinearRing>
</gml:interior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494031.22 272081.62 288.03</gml:pos>
<gml:pos srsDimension="3">494024.72 272096.10 288.03</gml:pos>
<gml:pos srsDimension="3">494024.72 272096.10 294.90</gml:pos>
<gml:pos srsDimension="3">494024.76 272096.01 294.99</gml:pos>
<gml:pos srsDimension="3">494027.51 272089.88 295.02</gml:pos>
<gml:pos srsDimension="3">494027.51 272089.88 297.47</gml:pos>
<gml:pos srsDimension="3">494027.96 272088.87 297.61</gml:pos>
<gml:pos srsDimension="3">494028.90 272086.79 297.33</gml:pos>
<gml:pos srsDimension="3">494028.90 272086.79 295.06</gml:pos>
<gml:pos srsDimension="3">494031.22 272081.62 294.96</gml:pos>
<gml:pos srsDimension="3">494031.22 272081.62 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494010.37 272072.25 288.03</gml:pos>
<gml:pos srsDimension="3">494031.22 272081.62 288.03</gml:pos>
<gml:pos srsDimension="3">494031.22 272081.62 294.96</gml:pos>
<gml:pos srsDimension="3">494031.15 272081.59 295.04</gml:pos>
<gml:pos srsDimension="3">494010.37 272072.25 295.02</gml:pos>
<gml:pos srsDimension="3">494010.37 272072.25 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494012.48 272067.56 288.03</gml:pos>
<gml:pos srsDimension="3">494010.37 272072.25 288.03</gml:pos>
<gml:pos srsDimension="3">494010.37 272072.25 295.02</gml:pos>
<gml:pos srsDimension="3">494012.39 272067.76 295.12</gml:pos>
<gml:pos srsDimension="3">494012.48 272067.56 294.89</gml:pos>
<gml:pos srsDimension="3">494012.48 272067.56 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_4">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_4_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493992.65 272058.69 288.03</gml:pos>
<gml:pos srsDimension="3">494012.48 272067.56 288.03</gml:pos>
<gml:pos srsDimension="3">494012.48 272067.56 294.89</gml:pos>
<gml:pos srsDimension="3">493992.65 272058.69 294.89</gml:pos>
<gml:pos srsDimension="3">493992.65 272058.69 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_5">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_5_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493990.64 272063.82 288.03</gml:pos>
<gml:pos srsDimension="3">493992.65 272058.69 288.03</gml:pos>
<gml:pos srsDimension="3">493992.65 272058.69 294.89</gml:pos>
<gml:pos srsDimension="3">493992.59 272058.84 295.06</gml:pos>
<gml:pos srsDimension="3">493990.64 272063.82 295.36</gml:pos>
<gml:pos srsDimension="3">493990.64 272063.82 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_6">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_6_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493989.33 272064.16 288.03</gml:pos>
<gml:pos srsDimension="3">493990.64 272063.82 288.03</gml:pos>
<gml:pos srsDimension="3">493990.64 272063.82 295.36</gml:pos>
<gml:pos srsDimension="3">493989.99 272063.99 294.81</gml:pos>
<gml:pos srsDimension="3">493989.33 272064.16 295.14</gml:pos>
<gml:pos srsDimension="3">493989.33 272064.16 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_7">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_7_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493988.28 272064.20 288.03</gml:pos>
<gml:pos srsDimension="3">493989.33 272064.16 288.03</gml:pos>
<gml:pos srsDimension="3">493989.33 272064.16 295.14</gml:pos>
<gml:pos srsDimension="3">493988.28 272064.20 295.50</gml:pos>
<gml:pos srsDimension="3">493988.28 272064.20 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_8">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_8_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493986.25 272063.11 288.03</gml:pos>
<gml:pos srsDimension="3">493988.28 272064.20 288.03</gml:pos>
<gml:pos srsDimension="3">493988.28 272064.20 295.50</gml:pos>
<gml:pos srsDimension="3">493986.25 272063.11 295.38</gml:pos>
<gml:pos srsDimension="3">493986.25 272063.11 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_9">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_9_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493985.24 272061.85 288.03</gml:pos>
<gml:pos srsDimension="3">493986.25 272063.11 288.03</gml:pos>
<gml:pos srsDimension="3">493986.25 272063.11 295.38</gml:pos>
<gml:pos srsDimension="3">493985.50 272062.17 294.96</gml:pos>
<gml:pos srsDimension="3">493985.24 272061.85 295.32</gml:pos>
<gml:pos srsDimension="3">493985.24 272061.85 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_10">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_10_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493987.51 272056.22 288.03</gml:pos>
<gml:pos srsDimension="3">493985.24 272061.85 288.03</gml:pos>
<gml:pos srsDimension="3">493985.24 272061.85 295.32</gml:pos>
<gml:pos srsDimension="3">493987.20 272056.99 295.52</gml:pos>
<gml:pos srsDimension="3">493987.51 272056.22 294.65</gml:pos>
<gml:pos srsDimension="3">493987.51 272056.22 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_11">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_11_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493979.05 272052.60 288.03</gml:pos>
<gml:pos srsDimension="3">493987.51 272056.22 288.03</gml:pos>
<gml:pos srsDimension="3">493987.51 272056.22 294.65</gml:pos>
<gml:pos srsDimension="3">493980.42 272053.19 294.77</gml:pos>
<gml:pos srsDimension="3">493979.05 272052.60 296.44</gml:pos>
<gml:pos srsDimension="3">493979.05 272052.60 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_12">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_12_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493976.74 272051.30 288.03</gml:pos>
<gml:pos srsDimension="3">493979.05 272052.60 288.03</gml:pos>
<gml:pos srsDimension="3">493979.05 272052.60 296.44</gml:pos>
<gml:pos srsDimension="3">493977.99 272052.00 297.79</gml:pos>
<gml:pos srsDimension="3">493976.74 272051.30 296.13</gml:pos>
<gml:pos srsDimension="3">493976.74 272051.30 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_13">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_13_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493968.20 272047.69 288.03</gml:pos>
<gml:pos srsDimension="3">493976.74 272051.30 288.03</gml:pos>
<gml:pos srsDimension="3">493976.74 272051.30 296.13</gml:pos>
<gml:pos srsDimension="3">493975.50 272050.78 294.56</gml:pos>
<gml:pos srsDimension="3">493968.20 272047.69 294.72</gml:pos>
<gml:pos srsDimension="3">493968.20 272047.69 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_14">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_14_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493966.06 272052.48 288.03</gml:pos>
<gml:pos srsDimension="3">493968.20 272047.69 288.03</gml:pos>
<gml:pos srsDimension="3">493968.20 272047.69 294.72</gml:pos>
<gml:pos srsDimension="3">493968.01 272048.12 295.21</gml:pos>
<gml:pos srsDimension="3">493966.06 272052.48 295.21</gml:pos>
<gml:pos srsDimension="3">493966.06 272052.48 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_15">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_15_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493964.63 272052.77 288.03</gml:pos>
<gml:pos srsDimension="3">493966.06 272052.48 288.03</gml:pos>
<gml:pos srsDimension="3">493966.06 272052.48 295.21</gml:pos>
<gml:pos srsDimension="3">493965.32 272052.63 294.57</gml:pos>
<gml:pos srsDimension="3">493964.63 272052.77 294.87</gml:pos>
<gml:pos srsDimension="3">493964.63 272052.77 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_16">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_16_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493963.41 272052.73 288.03</gml:pos>
<gml:pos srsDimension="3">493964.63 272052.77 288.03</gml:pos>
<gml:pos srsDimension="3">493964.63 272052.77 294.87</gml:pos>
<gml:pos srsDimension="3">493963.41 272052.73 295.19</gml:pos>
<gml:pos srsDimension="3">493963.41 272052.73 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_17">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_17_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493963.30 272052.68 288.03</gml:pos>
<gml:pos srsDimension="3">493963.41 272052.73 288.03</gml:pos>
<gml:pos srsDimension="3">493963.41 272052.73 295.19</gml:pos>
<gml:pos srsDimension="3">493963.30 272052.68 295.19</gml:pos>
<gml:pos srsDimension="3">493963.30 272052.68 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_18">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_18_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493962.21 272052.19 288.03</gml:pos>
<gml:pos srsDimension="3">493963.30 272052.68 288.03</gml:pos>
<gml:pos srsDimension="3">493963.30 272052.68 295.19</gml:pos>
<gml:pos srsDimension="3">493962.21 272052.19 295.16</gml:pos>
<gml:pos srsDimension="3">493962.21 272052.19 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_19">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_19_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493961.19 272051.18 288.03</gml:pos>
<gml:pos srsDimension="3">493962.21 272052.19 288.03</gml:pos>
<gml:pos srsDimension="3">493962.21 272052.19 295.16</gml:pos>
<gml:pos srsDimension="3">493961.19 272051.18 294.74</gml:pos>
<gml:pos srsDimension="3">493961.19 272051.18 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_20">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_20_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493960.68 272050.13 288.03</gml:pos>
<gml:pos srsDimension="3">493961.19 272051.18 288.03</gml:pos>
<gml:pos srsDimension="3">493961.19 272051.18 294.74</gml:pos>
<gml:pos srsDimension="3">493961.16 272051.11 294.71</gml:pos>
<gml:pos srsDimension="3">493960.68 272050.13 295.59</gml:pos>
<gml:pos srsDimension="3">493960.68 272050.13 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_21">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_21_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493962.69 272045.21 288.03</gml:pos>
<gml:pos srsDimension="3">493960.68 272050.13 288.03</gml:pos>
<gml:pos srsDimension="3">493960.68 272050.13 295.59</gml:pos>
<gml:pos srsDimension="3">493962.30 272046.18 295.75</gml:pos>
<gml:pos srsDimension="3">493962.69 272045.21 294.66</gml:pos>
<gml:pos srsDimension="3">493962.69 272045.21 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_22">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_22_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493946.08 272038.03 288.03</gml:pos>
<gml:pos srsDimension="3">493962.69 272045.21 288.03</gml:pos>
<gml:pos srsDimension="3">493962.69 272045.21 294.66</gml:pos>
<gml:pos srsDimension="3">493946.08 272038.03 294.79</gml:pos>
<gml:pos srsDimension="3">493946.08 272038.03 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_23">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_23_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493935.80 272062.03 288.03</gml:pos>
<gml:pos srsDimension="3">493946.08 272038.03 288.03</gml:pos>
<gml:pos srsDimension="3">493946.08 272038.03 294.79</gml:pos>
<gml:pos srsDimension="3">493945.97 272038.29 295.10</gml:pos>
<gml:pos srsDimension="3">493935.80 272062.03 295.36</gml:pos>
<gml:pos srsDimension="3">493935.80 272062.03 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_24">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_24_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493952.48 272069.23 288.03</gml:pos>
<gml:pos srsDimension="3">493935.80 272062.03 288.03</gml:pos>
<gml:pos srsDimension="3">493935.80 272062.03 295.36</gml:pos>
<gml:pos srsDimension="3">493935.94 272062.09 295.52</gml:pos>
<gml:pos srsDimension="3">493952.30 272069.15 295.72</gml:pos>
<gml:pos srsDimension="3">493952.48 272069.23 295.51</gml:pos>
<gml:pos srsDimension="3">493952.48 272069.23 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_25">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_25_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493954.49 272064.60 288.03</gml:pos>
<gml:pos srsDimension="3">493952.48 272069.23 288.03</gml:pos>
<gml:pos srsDimension="3">493952.48 272069.23 295.51</gml:pos>
<gml:pos srsDimension="3">493954.49 272064.60 295.47</gml:pos>
<gml:pos srsDimension="3">493954.49 272064.60 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_26">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_26_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493955.08 272064.33 288.03</gml:pos>
<gml:pos srsDimension="3">493954.49 272064.60 288.03</gml:pos>
<gml:pos srsDimension="3">493954.49 272064.60 295.47</gml:pos>
<gml:pos srsDimension="3">493954.91 272064.41 295.14</gml:pos>
<gml:pos srsDimension="3">493955.08 272064.33 295.25</gml:pos>
<gml:pos srsDimension="3">493955.08 272064.33 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_27">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_27_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493956.07 272064.24 288.03</gml:pos>
<gml:pos srsDimension="3">493955.08 272064.33 288.03</gml:pos>
<gml:pos srsDimension="3">493955.08 272064.33 295.25</gml:pos>
<gml:pos srsDimension="3">493956.07 272064.24 295.61</gml:pos>
<gml:pos srsDimension="3">493956.07 272064.24 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_28">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_28_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493958.81 272065.48 288.03</gml:pos>
<gml:pos srsDimension="3">493956.07 272064.24 288.03</gml:pos>
<gml:pos srsDimension="3">493956.07 272064.24 295.61</gml:pos>
<gml:pos srsDimension="3">493958.81 272065.48 295.55</gml:pos>
<gml:pos srsDimension="3">493958.81 272065.48 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_29">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_29_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493959.70 272066.30 288.03</gml:pos>
<gml:pos srsDimension="3">493958.81 272065.48 288.03</gml:pos>
<gml:pos srsDimension="3">493958.81 272065.48 295.55</gml:pos>
<gml:pos srsDimension="3">493959.62 272066.23 295.26</gml:pos>
<gml:pos srsDimension="3">493959.70 272066.30 295.36</gml:pos>
<gml:pos srsDimension="3">493959.70 272066.30 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_30">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_30_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493959.86 272067.09 288.03</gml:pos>
<gml:pos srsDimension="3">493959.70 272066.30 288.03</gml:pos>
<gml:pos srsDimension="3">493959.70 272066.30 295.36</gml:pos>
<gml:pos srsDimension="3">493959.86 272067.09 295.85</gml:pos>
<gml:pos srsDimension="3">493959.86 272067.09 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_31">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_31_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493957.95 272071.60 288.03</gml:pos>
<gml:pos srsDimension="3">493959.86 272067.09 288.03</gml:pos>
<gml:pos srsDimension="3">493959.86 272067.09 295.85</gml:pos>
<gml:pos srsDimension="3">493957.95 272071.60 295.93</gml:pos>
<gml:pos srsDimension="3">493957.95 272071.60 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_32">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_32_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493977.20 272080.20 288.03</gml:pos>
<gml:pos srsDimension="3">493957.95 272071.60 288.03</gml:pos>
<gml:pos srsDimension="3">493957.95 272071.60 295.93</gml:pos>
<gml:pos srsDimension="3">493958.27 272071.74 296.29</gml:pos>
<gml:pos srsDimension="3">493976.79 272080.01 296.19</gml:pos>
<gml:pos srsDimension="3">493977.20 272080.20 295.71</gml:pos>
<gml:pos srsDimension="3">493977.20 272080.20 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_33">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_33_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493979.20 272075.21 288.03</gml:pos>
<gml:pos srsDimension="3">493977.20 272080.20 288.03</gml:pos>
<gml:pos srsDimension="3">493977.20 272080.20 295.71</gml:pos>
<gml:pos srsDimension="3">493979.20 272075.21 295.82</gml:pos>
<gml:pos srsDimension="3">493979.20 272075.21 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_34">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_34_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493980.87 272075.27 288.03</gml:pos>
<gml:pos srsDimension="3">493979.20 272075.21 288.03</gml:pos>
<gml:pos srsDimension="3">493979.20 272075.21 295.82</gml:pos>
<gml:pos srsDimension="3">493979.72 272075.23 295.30</gml:pos>
<gml:pos srsDimension="3">493980.87 272075.27 295.57</gml:pos>
<gml:pos srsDimension="3">493980.87 272075.27 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_35">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_35_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493982.65 272076.01 288.03</gml:pos>
<gml:pos srsDimension="3">493980.87 272075.27 288.03</gml:pos>
<gml:pos srsDimension="3">493980.87 272075.27 295.57</gml:pos>
<gml:pos srsDimension="3">493982.65 272076.01 295.54</gml:pos>
<gml:pos srsDimension="3">493982.65 272076.01 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_36">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_36_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493983.51 272076.43 288.03</gml:pos>
<gml:pos srsDimension="3">493982.65 272076.01 288.03</gml:pos>
<gml:pos srsDimension="3">493982.65 272076.01 295.54</gml:pos>
<gml:pos srsDimension="3">493983.51 272076.43 295.49</gml:pos>
<gml:pos srsDimension="3">493983.51 272076.43 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_37">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_37_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493984.42 272077.73 288.03</gml:pos>
<gml:pos srsDimension="3">493983.51 272076.43 288.03</gml:pos>
<gml:pos srsDimension="3">493983.51 272076.43 295.49</gml:pos>
<gml:pos srsDimension="3">493984.23 272077.46 294.99</gml:pos>
<gml:pos srsDimension="3">493984.42 272077.73 295.29</gml:pos>
<gml:pos srsDimension="3">493984.42 272077.73 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_38">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_38_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493982.36 272082.65 288.03</gml:pos>
<gml:pos srsDimension="3">493984.42 272077.73 288.03</gml:pos>
<gml:pos srsDimension="3">493984.42 272077.73 295.29</gml:pos>
<gml:pos srsDimension="3">493982.36 272082.65 295.32</gml:pos>
<gml:pos srsDimension="3">493982.36 272082.65 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_39">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_39_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494001.90 272091.59 288.03</gml:pos>
<gml:pos srsDimension="3">493982.36 272082.65 288.03</gml:pos>
<gml:pos srsDimension="3">493982.36 272082.65 295.32</gml:pos>
<gml:pos srsDimension="3">493982.42 272082.68 295.39</gml:pos>
<gml:pos srsDimension="3">494001.90 272091.59 294.93</gml:pos>
<gml:pos srsDimension="3">494001.90 272091.59 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_40">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_40_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494003.82 272087.00 288.03</gml:pos>
<gml:pos srsDimension="3">494001.90 272091.59 288.03</gml:pos>
<gml:pos srsDimension="3">494001.90 272091.59 294.93</gml:pos>
<gml:pos srsDimension="3">494001.92 272091.54 294.98</gml:pos>
<gml:pos srsDimension="3">494003.82 272087.00 294.96</gml:pos>
<gml:pos srsDimension="3">494003.82 272087.00 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_41">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_41_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494024.72 272096.10 288.03</gml:pos>
<gml:pos srsDimension="3">494003.82 272087.00 288.03</gml:pos>
<gml:pos srsDimension="3">494003.82 272087.00 294.96</gml:pos>
<gml:pos srsDimension="3">494024.72 272096.10 294.90</gml:pos>
<gml:pos srsDimension="3">494024.72 272096.10 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_42">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_42_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493946.80 272055.99 288.03</gml:pos>
<gml:pos srsDimension="3">493946.80 272055.99 295.50</gml:pos>
<gml:pos srsDimension="3">493949.22 272050.31 295.55</gml:pos>
<gml:pos srsDimension="3">493949.29 272050.15 295.61</gml:pos>
<gml:pos srsDimension="3">493949.29 272050.15 288.03</gml:pos>
<gml:pos srsDimension="3">493946.80 272055.99 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_43">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_43_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493949.29 272050.15 288.03</gml:pos>
<gml:pos srsDimension="3">493949.29 272050.15 295.61</gml:pos>
<gml:pos srsDimension="3">493954.99 272052.58 295.61</gml:pos>
<gml:pos srsDimension="3">493954.99 272052.58 288.03</gml:pos>
<gml:pos srsDimension="3">493949.29 272050.15 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_44">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_44_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493954.99 272052.58 288.03</gml:pos>
<gml:pos srsDimension="3">493954.99 272052.58 295.61</gml:pos>
<gml:pos srsDimension="3">493954.57 272053.57 295.25</gml:pos>
<gml:pos srsDimension="3">493952.49 272058.42 295.28</gml:pos>
<gml:pos srsDimension="3">493952.49 272058.42 288.03</gml:pos>
<gml:pos srsDimension="3">493954.99 272052.58 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_45">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_45_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493952.49 272058.42 288.03</gml:pos>
<gml:pos srsDimension="3">493952.49 272058.42 295.28</gml:pos>
<gml:pos srsDimension="3">493952.44 272058.40 295.26</gml:pos>
<gml:pos srsDimension="3">493947.22 272056.17 295.29</gml:pos>
<gml:pos srsDimension="3">493946.80 272055.99 295.50</gml:pos>
<gml:pos srsDimension="3">493946.80 272055.99 288.03</gml:pos>
<gml:pos srsDimension="3">493952.49 272058.42 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_46">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_46_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493979.22 272063.79 288.03</gml:pos>
<gml:pos srsDimension="3">493979.22 272063.79 295.43</gml:pos>
<gml:pos srsDimension="3">493978.96 272064.39 295.22</gml:pos>
<gml:pos srsDimension="3">493976.79 272069.33 295.23</gml:pos>
<gml:pos srsDimension="3">493976.76 272069.40 295.26</gml:pos>
<gml:pos srsDimension="3">493976.76 272069.40 288.03</gml:pos>
<gml:pos srsDimension="3">493979.22 272063.79 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_47">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_47_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493976.76 272069.40 288.03</gml:pos>
<gml:pos srsDimension="3">493976.76 272069.40 295.26</gml:pos>
<gml:pos srsDimension="3">493967.06 272065.13 295.32</gml:pos>
<gml:pos srsDimension="3">493966.90 272065.06 295.37</gml:pos>
<gml:pos srsDimension="3">493966.90 272065.06 288.03</gml:pos>
<gml:pos srsDimension="3">493976.76 272069.40 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_48">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_48_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493966.90 272065.06 288.03</gml:pos>
<gml:pos srsDimension="3">493966.90 272065.06 295.37</gml:pos>
<gml:pos srsDimension="3">493969.25 272059.73 295.35</gml:pos>
<gml:pos srsDimension="3">493969.37 272059.45 295.45</gml:pos>
<gml:pos srsDimension="3">493969.37 272059.45 288.03</gml:pos>
<gml:pos srsDimension="3">493966.90 272065.06 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_49">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_49_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493969.37 272059.45 288.03</gml:pos>
<gml:pos srsDimension="3">493969.37 272059.45 295.45</gml:pos>
<gml:pos srsDimension="3">493979.22 272063.79 295.43</gml:pos>
<gml:pos srsDimension="3">493979.22 272063.79 288.03</gml:pos>
<gml:pos srsDimension="3">493969.37 272059.45 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_50">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_50_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494005.34 272081.97 288.03</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 295.23</gml:pos>
<gml:pos srsDimension="3">493989.73 272075.03 295.25</gml:pos>
<gml:pos srsDimension="3">493989.59 272074.97 295.31</gml:pos>
<gml:pos srsDimension="3">493989.59 272074.97 288.03</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_51">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_51_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493989.59 272074.97 288.03</gml:pos>
<gml:pos srsDimension="3">493989.59 272074.97 295.31</gml:pos>
<gml:pos srsDimension="3">493991.92 272069.71 295.31</gml:pos>
<gml:pos srsDimension="3">493992.10 272069.30 295.46</gml:pos>
<gml:pos srsDimension="3">493992.10 272069.30 288.03</gml:pos>
<gml:pos srsDimension="3">493989.59 272074.97 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_52">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_52_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493992.10 272069.30 288.03</gml:pos>
<gml:pos srsDimension="3">493992.10 272069.30 295.46</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 295.39</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 288.03</gml:pos>
<gml:pos srsDimension="3">493992.10 272069.30 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_53">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_53_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494007.86 272076.30 288.03</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 295.39</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 297.31</gml:pos>
<gml:pos srsDimension="3">494006.48 272079.42 297.73</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 297.37</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 295.23</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 288.03</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 288.03</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_54">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_54_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494003.51 272086.05 295.64</gml:pos>
<gml:pos srsDimension="3">494004.11 272084.74 295.59</gml:pos>
<gml:pos srsDimension="3">494005.03 272082.76 295.50</gml:pos>
<gml:pos srsDimension="3">494005.03 272082.76 297.26</gml:pos>
<gml:pos srsDimension="3">494004.11 272084.74 296.98</gml:pos>
<gml:pos srsDimension="3">494003.51 272086.05 295.64</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_55">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_55_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494003.51 272086.05 295.64</gml:pos>
<gml:pos srsDimension="3">494003.21 272086.71 294.96</gml:pos>
<gml:pos srsDimension="3">494003.21 272086.71 295.66</gml:pos>
<gml:pos srsDimension="3">494003.51 272086.05 295.64</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_56">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_56_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494003.21 272086.71 294.96</gml:pos>
<gml:pos srsDimension="3">494003.82 272087.00 294.96</gml:pos>
<gml:pos srsDimension="3">494003.21 272086.71 295.66</gml:pos>
<gml:pos srsDimension="3">494003.21 272086.71 294.96</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_57">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_57_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494024.98 272085.09 297.35</gml:pos>
<gml:pos srsDimension="3">494027.07 272086.00 296.93</gml:pos>
<gml:pos srsDimension="3">494028.90 272086.79 295.06</gml:pos>
<gml:pos srsDimension="3">494028.90 272086.79 297.33</gml:pos>
<gml:pos srsDimension="3">494027.07 272086.00 297.34</gml:pos>
<gml:pos srsDimension="3">494024.98 272085.09 297.35</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_58">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_58_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494027.51 272089.88 295.02</gml:pos>
<gml:pos srsDimension="3">494025.64 272089.06 296.94</gml:pos>
<gml:pos srsDimension="3">494023.19 272087.99 297.49</gml:pos>
<gml:pos srsDimension="3">494025.64 272089.06 297.48</gml:pos>
<gml:pos srsDimension="3">494027.51 272089.88 297.47</gml:pos>
<gml:pos srsDimension="3">494027.51 272089.88 295.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_59">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_59_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494005.03 272082.76 295.50</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 295.23</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 297.37</gml:pos>
<gml:pos srsDimension="3">494005.03 272082.76 297.26</gml:pos>
<gml:pos srsDimension="3">494005.03 272082.76 295.50</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_60">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_60_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493980.24 272058.86 297.07</gml:pos>
<gml:pos srsDimension="3">493978.57 272062.38 295.77</gml:pos>
<gml:pos srsDimension="3">493978.57 272062.38 297.07</gml:pos>
<gml:pos srsDimension="3">493980.24 272058.86 297.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_61">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_61_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493978.57 272062.38 295.77</gml:pos>
<gml:pos srsDimension="3">493976.88 272061.64 295.78</gml:pos>
<gml:pos srsDimension="3">493975.27 272060.92 295.78</gml:pos>
<gml:pos srsDimension="3">493975.27 272060.92 297.03</gml:pos>
<gml:pos srsDimension="3">493976.88 272061.64 297.76</gml:pos>
<gml:pos srsDimension="3">493978.57 272062.38 297.07</gml:pos>
<gml:pos srsDimension="3">493978.57 272062.38 295.77</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_62">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_62_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494008.93 272074.00 295.62</gml:pos>
<gml:pos srsDimension="3">494009.56 272072.63 295.63</gml:pos>
<gml:pos srsDimension="3">494008.93 272074.00 297.02</gml:pos>
<gml:pos srsDimension="3">494008.93 272074.00 295.62</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_63">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_63_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494009.84 272072.01 295.01</gml:pos>
<gml:pos srsDimension="3">494009.56 272072.63 295.63</gml:pos>
<gml:pos srsDimension="3">494009.84 272072.01 295.64</gml:pos>
<gml:pos srsDimension="3">494009.84 272072.01 295.01</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_64">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_64_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494010.37 272072.25 295.02</gml:pos>
<gml:pos srsDimension="3">494009.84 272072.01 295.01</gml:pos>
<gml:pos srsDimension="3">494009.84 272072.01 295.64</gml:pos>
<gml:pos srsDimension="3">494010.37 272072.25 295.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_65">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_65_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494007.86 272076.30 295.39</gml:pos>
<gml:pos srsDimension="3">494008.18 272075.56 295.64</gml:pos>
<gml:pos srsDimension="3">494008.18 272075.56 297.22</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 297.31</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 295.39</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_66">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_66_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494008.18 272075.56 295.64</gml:pos>
<gml:pos srsDimension="3">494008.93 272074.00 295.62</gml:pos>
<gml:pos srsDimension="3">494008.93 272074.00 297.02</gml:pos>
<gml:pos srsDimension="3">494008.18 272075.56 297.22</gml:pos>
<gml:pos srsDimension="3">494008.18 272075.56 295.64</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_67">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_WS_67_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493975.27 272060.92 295.78</gml:pos>
<gml:pos srsDimension="3">493976.82 272057.35 297.08</gml:pos>
<gml:pos srsDimension="3">493975.27 272060.92 297.03</gml:pos>
<gml:pos srsDimension="3">493975.27 272060.92 295.78</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494003.82 272087.00 294.96</gml:pos>
<gml:pos srsDimension="3">494001.92 272091.54 294.98</gml:pos>
<gml:pos srsDimension="3">494000.42 272088.09 297.74</gml:pos>
<gml:pos srsDimension="3">494005.03 272082.76 295.50</gml:pos>
<gml:pos srsDimension="3">494004.11 272084.74 295.59</gml:pos>
<gml:pos srsDimension="3">494003.51 272086.05 295.64</gml:pos>
<gml:pos srsDimension="3">494003.21 272086.71 295.66</gml:pos>
<gml:pos srsDimension="3">494003.82 272087.00 294.96</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493985.50 272062.17 294.96</gml:pos>
<gml:pos srsDimension="3">493986.25 272063.11 295.38</gml:pos>
<gml:pos srsDimension="3">493988.28 272064.20 295.50</gml:pos>
<gml:pos srsDimension="3">493989.33 272064.16 295.14</gml:pos>
<gml:pos srsDimension="3">493989.99 272063.99 294.81</gml:pos>
<gml:pos srsDimension="3">493990.44 272066.17 296.20</gml:pos>
<gml:pos srsDimension="3">493990.87 272066.36 296.19</gml:pos>
<gml:pos srsDimension="3">493986.18 272066.51 297.79</gml:pos>
<gml:pos srsDimension="3">493983.34 272063.31 296.45</gml:pos>
<gml:pos srsDimension="3">493985.50 272062.17 294.96</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493976.79 272080.01 296.19</gml:pos>
<gml:pos srsDimension="3">493958.27 272071.74 296.29</gml:pos>
<gml:pos srsDimension="3">493960.85 272070.70 298.31</gml:pos>
<gml:pos srsDimension="3">493975.81 272077.36 298.25</gml:pos>
<gml:pos srsDimension="3">493976.79 272080.01 296.19</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_4">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_4_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493975.50 272050.78 294.56</gml:pos>
<gml:pos srsDimension="3">493976.74 272051.30 296.13</gml:pos>
<gml:pos srsDimension="3">493977.99 272052.00 297.79</gml:pos>
<gml:pos srsDimension="3">493976.82 272054.75 297.79</gml:pos>
<gml:pos srsDimension="3">493975.50 272050.78 294.56</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_5">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_5_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493977.99 272052.00 297.79</gml:pos>
<gml:pos srsDimension="3">493979.05 272052.60 296.44</gml:pos>
<gml:pos srsDimension="3">493980.42 272053.19 294.77</gml:pos>
<gml:pos srsDimension="3">493976.82 272054.75 297.79</gml:pos>
<gml:pos srsDimension="3">493977.99 272052.00 297.79</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_6">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_6_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494028.41 272082.88 296.93</gml:pos>
<gml:pos srsDimension="3">494027.07 272086.00 296.93</gml:pos>
<gml:pos srsDimension="3">494024.98 272085.09 297.35</gml:pos>
<gml:pos srsDimension="3">494028.41 272082.88 296.93</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_7">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_7_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494031.15 272081.59 295.04</gml:pos>
<gml:pos srsDimension="3">494031.22 272081.62 294.96</gml:pos>
<gml:pos srsDimension="3">494028.90 272086.79 295.06</gml:pos>
<gml:pos srsDimension="3">494027.07 272086.00 296.93</gml:pos>
<gml:pos srsDimension="3">494028.41 272082.88 296.93</gml:pos>
<gml:pos srsDimension="3">494028.54 272082.64 296.90</gml:pos>
<gml:pos srsDimension="3">494031.15 272081.59 295.04</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_8">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_8_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494027.51 272089.88 295.02</gml:pos>
<gml:pos srsDimension="3">494024.76 272096.01 294.99</gml:pos>
<gml:pos srsDimension="3">494023.72 272093.40 296.87</gml:pos>
<gml:pos srsDimension="3">494025.64 272089.06 296.94</gml:pos>
<gml:pos srsDimension="3">494027.51 272089.88 295.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_9">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_9_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493977.20 272080.20 295.71</gml:pos>
<gml:pos srsDimension="3">493976.79 272080.01 296.19</gml:pos>
<gml:pos srsDimension="3">493975.81 272077.36 298.25</gml:pos>
<gml:pos srsDimension="3">493978.92 272074.06 296.56</gml:pos>
<gml:pos srsDimension="3">493979.30 272073.18 296.56</gml:pos>
<gml:pos srsDimension="3">493979.72 272075.23 295.30</gml:pos>
<gml:pos srsDimension="3">493979.20 272075.21 295.82</gml:pos>
<gml:pos srsDimension="3">493977.20 272080.20 295.71</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_10">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_10_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493992.59 272058.84 295.06</gml:pos>
<gml:pos srsDimension="3">493992.65 272058.69 294.89</gml:pos>
<gml:pos srsDimension="3">494012.48 272067.56 294.89</gml:pos>
<gml:pos srsDimension="3">494012.39 272067.76 295.12</gml:pos>
<gml:pos srsDimension="3">494008.97 272068.95 297.76</gml:pos>
<gml:pos srsDimension="3">493993.90 272062.29 297.82</gml:pos>
<gml:pos srsDimension="3">493992.59 272058.84 295.06</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_11">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_11_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493962.30 272046.18 295.75</gml:pos>
<gml:pos srsDimension="3">493960.68 272050.13 295.59</gml:pos>
<gml:pos srsDimension="3">493961.16 272051.11 294.71</gml:pos>
<gml:pos srsDimension="3">493958.71 272052.57 296.43</gml:pos>
<gml:pos srsDimension="3">493959.11 272051.69 296.43</gml:pos>
<gml:pos srsDimension="3">493959.62 272047.21 297.88</gml:pos>
<gml:pos srsDimension="3">493962.30 272046.18 295.75</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_12">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_12_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493952.44 272058.40 295.26</gml:pos>
<gml:pos srsDimension="3">493954.09 272063.10 296.47</gml:pos>
<gml:pos srsDimension="3">493951.22 272066.43 297.87</gml:pos>
<gml:pos srsDimension="3">493938.89 272060.95 297.88</gml:pos>
<gml:pos srsDimension="3">493947.22 272056.17 295.29</gml:pos>
<gml:pos srsDimension="3">493952.44 272058.40 295.26</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_13">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_13_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494001.92 272091.54 294.98</gml:pos>
<gml:pos srsDimension="3">494001.90 272091.59 294.93</gml:pos>
<gml:pos srsDimension="3">493982.42 272082.68 295.39</gml:pos>
<gml:pos srsDimension="3">493985.39 272081.52 297.80</gml:pos>
<gml:pos srsDimension="3">494000.42 272088.09 297.74</gml:pos>
<gml:pos srsDimension="3">494001.92 272091.54 294.98</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_14">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_14_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493954.91 272064.41 295.14</gml:pos>
<gml:pos srsDimension="3">493954.49 272064.60 295.47</gml:pos>
<gml:pos srsDimension="3">493952.48 272069.23 295.51</gml:pos>
<gml:pos srsDimension="3">493952.30 272069.15 295.72</gml:pos>
<gml:pos srsDimension="3">493951.22 272066.43 297.87</gml:pos>
<gml:pos srsDimension="3">493954.09 272063.10 296.47</gml:pos>
<gml:pos srsDimension="3">493954.41 272062.36 296.46</gml:pos>
<gml:pos srsDimension="3">493954.91 272064.41 295.14</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_15">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_15_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493976.79 272069.33 295.23</gml:pos>
<gml:pos srsDimension="3">493978.92 272074.06 296.56</gml:pos>
<gml:pos srsDimension="3">493975.81 272077.36 298.25</gml:pos>
<gml:pos srsDimension="3">493960.85 272070.70 298.31</gml:pos>
<gml:pos srsDimension="3">493961.10 272066.43 296.75</gml:pos>
<gml:pos srsDimension="3">493967.06 272065.13 295.32</gml:pos>
<gml:pos srsDimension="3">493976.76 272069.40 295.26</gml:pos>
<gml:pos srsDimension="3">493976.79 272069.33 295.23</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_16">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_16_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494027.96 272088.87 297.61</gml:pos>
<gml:pos srsDimension="3">494027.51 272089.88 297.47</gml:pos>
<gml:pos srsDimension="3">494025.64 272089.06 297.48</gml:pos>
<gml:pos srsDimension="3">494023.19 272087.99 297.49</gml:pos>
<gml:pos srsDimension="3">494023.72 272093.40 296.87</gml:pos>
<gml:pos srsDimension="3">494004.11 272084.74 296.98</gml:pos>
<gml:pos srsDimension="3">494005.03 272082.76 297.26</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 297.37</gml:pos>
<gml:pos srsDimension="3">494006.48 272079.42 297.73</gml:pos>
<gml:pos srsDimension="3">494027.96 272088.87 297.61</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_17">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_17_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493968.20 272047.69 294.72</gml:pos>
<gml:pos srsDimension="3">493975.50 272050.78 294.56</gml:pos>
<gml:pos srsDimension="3">493976.82 272054.75 297.79</gml:pos>
<gml:pos srsDimension="3">493980.42 272053.19 294.77</gml:pos>
<gml:pos srsDimension="3">493987.51 272056.22 294.65</gml:pos>
<gml:pos srsDimension="3">493987.20 272056.99 295.52</gml:pos>
<gml:pos srsDimension="3">493984.18 272058.06 297.83</gml:pos>
<gml:pos srsDimension="3">493969.31 272051.48 297.87</gml:pos>
<gml:pos srsDimension="3">493968.01 272048.12 295.21</gml:pos>
<gml:pos srsDimension="3">493968.20 272047.69 294.72</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_18">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_18_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494005.03 272082.76 295.50</gml:pos>
<gml:pos srsDimension="3">494000.42 272088.09 297.74</gml:pos>
<gml:pos srsDimension="3">493985.39 272081.52 297.80</gml:pos>
<gml:pos srsDimension="3">493985.91 272076.36 296.17</gml:pos>
<gml:pos srsDimension="3">493986.42 272076.57 296.16</gml:pos>
<gml:pos srsDimension="3">493989.73 272075.03 295.25</gml:pos>
<gml:pos srsDimension="3">494005.34 272081.97 295.23</gml:pos>
<gml:pos srsDimension="3">494005.03 272082.76 295.50</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_19">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_19_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493961.16 272051.11 294.71</gml:pos>
<gml:pos srsDimension="3">493961.19 272051.18 294.74</gml:pos>
<gml:pos srsDimension="3">493962.21 272052.19 295.16</gml:pos>
<gml:pos srsDimension="3">493963.30 272052.68 295.19</gml:pos>
<gml:pos srsDimension="3">493963.41 272052.73 295.19</gml:pos>
<gml:pos srsDimension="3">493964.63 272052.77 294.87</gml:pos>
<gml:pos srsDimension="3">493965.32 272052.63 294.57</gml:pos>
<gml:pos srsDimension="3">493966.05 272055.88 296.64</gml:pos>
<gml:pos srsDimension="3">493961.64 272055.76 297.82</gml:pos>
<gml:pos srsDimension="3">493958.71 272052.57 296.43</gml:pos>
<gml:pos srsDimension="3">493961.16 272051.11 294.71</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_20">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_20_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493989.99 272063.99 294.81</gml:pos>
<gml:pos srsDimension="3">493990.64 272063.82 295.36</gml:pos>
<gml:pos srsDimension="3">493992.59 272058.84 295.06</gml:pos>
<gml:pos srsDimension="3">493993.90 272062.29 297.82</gml:pos>
<gml:pos srsDimension="3">493990.44 272066.17 296.20</gml:pos>
<gml:pos srsDimension="3">493989.99 272063.99 294.81</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_21">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_21_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493979.36 272055.95 297.84</gml:pos>
<gml:pos srsDimension="3">493980.24 272058.86 297.07</gml:pos>
<gml:pos srsDimension="3">493978.57 272062.38 297.07</gml:pos>
<gml:pos srsDimension="3">493976.88 272061.64 297.76</gml:pos>
<gml:pos srsDimension="3">493979.36 272055.95 297.84</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_22">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_22_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493965.32 272052.63 294.57</gml:pos>
<gml:pos srsDimension="3">493966.06 272052.48 295.21</gml:pos>
<gml:pos srsDimension="3">493968.01 272048.12 295.21</gml:pos>
<gml:pos srsDimension="3">493969.31 272051.48 297.87</gml:pos>
<gml:pos srsDimension="3">493966.70 272054.42 296.63</gml:pos>
<gml:pos srsDimension="3">493966.05 272055.88 296.64</gml:pos>
<gml:pos srsDimension="3">493965.32 272052.63 294.57</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_23">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_23_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493959.62 272066.23 295.26</gml:pos>
<gml:pos srsDimension="3">493958.81 272065.48 295.55</gml:pos>
<gml:pos srsDimension="3">493956.07 272064.24 295.61</gml:pos>
<gml:pos srsDimension="3">493955.08 272064.33 295.25</gml:pos>
<gml:pos srsDimension="3">493954.91 272064.41 295.14</gml:pos>
<gml:pos srsDimension="3">493954.41 272062.36 296.46</gml:pos>
<gml:pos srsDimension="3">493958.77 272062.26 297.84</gml:pos>
<gml:pos srsDimension="3">493961.72 272065.03 296.75</gml:pos>
<gml:pos srsDimension="3">493959.62 272066.23 295.26</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_24">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_24_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493982.36 272082.65 295.32</gml:pos>
<gml:pos srsDimension="3">493984.42 272077.73 295.29</gml:pos>
<gml:pos srsDimension="3">493984.23 272077.46 294.99</gml:pos>
<gml:pos srsDimension="3">493985.91 272076.36 296.17</gml:pos>
<gml:pos srsDimension="3">493985.39 272081.52 297.80</gml:pos>
<gml:pos srsDimension="3">493982.42 272082.68 295.39</gml:pos>
<gml:pos srsDimension="3">493982.36 272082.65 295.32</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_25">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_25_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493952.44 272058.40 295.26</gml:pos>
<gml:pos srsDimension="3">493952.49 272058.42 295.28</gml:pos>
<gml:pos srsDimension="3">493954.57 272053.57 295.25</gml:pos>
<gml:pos srsDimension="3">493959.11 272051.69 296.43</gml:pos>
<gml:pos srsDimension="3">493958.71 272052.57 296.43</gml:pos>
<gml:pos srsDimension="3">493961.64 272055.76 297.82</gml:pos>
<gml:pos srsDimension="3">493958.77 272062.26 297.84</gml:pos>
<gml:pos srsDimension="3">493954.41 272062.36 296.46</gml:pos>
<gml:pos srsDimension="3">493954.09 272063.10 296.47</gml:pos>
<gml:pos srsDimension="3">493952.44 272058.40 295.26</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_26">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_26_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493976.79 272069.33 295.23</gml:pos>
<gml:pos srsDimension="3">493978.96 272064.39 295.22</gml:pos>
<gml:pos srsDimension="3">493983.75 272062.41 296.45</gml:pos>
<gml:pos srsDimension="3">493983.34 272063.31 296.45</gml:pos>
<gml:pos srsDimension="3">493986.18 272066.51 297.79</gml:pos>
<gml:pos srsDimension="3">493983.33 272072.91 297.80</gml:pos>
<gml:pos srsDimension="3">493979.30 272073.18 296.56</gml:pos>
<gml:pos srsDimension="3">493978.92 272074.06 296.56</gml:pos>
<gml:pos srsDimension="3">493976.79 272069.33 295.23</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_27">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_27_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494010.37 272072.25 295.02</gml:pos>
<gml:pos srsDimension="3">494031.15 272081.59 295.04</gml:pos>
<gml:pos srsDimension="3">494028.54 272082.64 296.90</gml:pos>
<gml:pos srsDimension="3">494008.93 272074.00 297.02</gml:pos>
<gml:pos srsDimension="3">494009.56 272072.63 295.63</gml:pos>
<gml:pos srsDimension="3">494009.84 272072.01 295.01</gml:pos>
<gml:pos srsDimension="3">494010.37 272072.25 295.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_28">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_28_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493991.92 272069.71 295.31</gml:pos>
<gml:pos srsDimension="3">493989.59 272074.97 295.31</gml:pos>
<gml:pos srsDimension="3">493989.73 272075.03 295.25</gml:pos>
<gml:pos srsDimension="3">493986.42 272076.57 296.16</gml:pos>
<gml:pos srsDimension="3">493983.33 272072.91 297.80</gml:pos>
<gml:pos srsDimension="3">493986.18 272066.51 297.79</gml:pos>
<gml:pos srsDimension="3">493990.87 272066.36 296.19</gml:pos>
<gml:pos srsDimension="3">493991.92 272069.71 295.31</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_29">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_29_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493982.65 272076.01 295.54</gml:pos>
<gml:pos srsDimension="3">493980.87 272075.27 295.57</gml:pos>
<gml:pos srsDimension="3">493979.72 272075.23 295.30</gml:pos>
<gml:pos srsDimension="3">493979.30 272073.18 296.56</gml:pos>
<gml:pos srsDimension="3">493983.33 272072.91 297.80</gml:pos>
<gml:pos srsDimension="3">493986.42 272076.57 296.16</gml:pos>
<gml:pos srsDimension="3">493985.91 272076.36 296.17</gml:pos>
<gml:pos srsDimension="3">493984.23 272077.46 294.99</gml:pos>
<gml:pos srsDimension="3">493983.51 272076.43 295.49</gml:pos>
<gml:pos srsDimension="3">493982.65 272076.01 295.54</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_30">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_30_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493958.27 272071.74 296.29</gml:pos>
<gml:pos srsDimension="3">493957.95 272071.60 295.93</gml:pos>
<gml:pos srsDimension="3">493959.86 272067.09 295.85</gml:pos>
<gml:pos srsDimension="3">493959.70 272066.30 295.36</gml:pos>
<gml:pos srsDimension="3">493959.62 272066.23 295.26</gml:pos>
<gml:pos srsDimension="3">493961.72 272065.03 296.75</gml:pos>
<gml:pos srsDimension="3">493961.10 272066.43 296.75</gml:pos>
<gml:pos srsDimension="3">493960.85 272070.70 298.31</gml:pos>
<gml:pos srsDimension="3">493958.27 272071.74 296.29</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_31">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_31_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494028.90 272086.79 297.33</gml:pos>
<gml:pos srsDimension="3">494027.96 272088.87 297.61</gml:pos>
<gml:pos srsDimension="3">494006.48 272079.42 297.73</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 297.31</gml:pos>
<gml:pos srsDimension="3">494008.18 272075.56 297.22</gml:pos>
<gml:pos srsDimension="3">494008.93 272074.00 297.02</gml:pos>
<gml:pos srsDimension="3">494028.54 272082.64 296.90</gml:pos>
<gml:pos srsDimension="3">494028.41 272082.88 296.93</gml:pos>
<gml:pos srsDimension="3">494024.98 272085.09 297.35</gml:pos>
<gml:pos srsDimension="3">494027.07 272086.00 297.34</gml:pos>
<gml:pos srsDimension="3">494028.90 272086.79 297.33</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_32">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_32_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493935.80 272062.03 295.36</gml:pos>
<gml:pos srsDimension="3">493945.97 272038.29 295.10</gml:pos>
<gml:pos srsDimension="3">493947.34 272041.84 297.92</gml:pos>
<gml:pos srsDimension="3">493938.89 272060.95 297.88</gml:pos>
<gml:pos srsDimension="3">493935.94 272062.09 295.52</gml:pos>
<gml:pos srsDimension="3">493935.80 272062.03 295.36</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_33">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_33_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493947.34 272041.84 297.92</gml:pos>
<gml:pos srsDimension="3">493959.62 272047.21 297.88</gml:pos>
<gml:pos srsDimension="3">493959.11 272051.69 296.43</gml:pos>
<gml:pos srsDimension="3">493954.57 272053.57 295.25</gml:pos>
<gml:pos srsDimension="3">493954.99 272052.58 295.61</gml:pos>
<gml:pos srsDimension="3">493949.29 272050.15 295.61</gml:pos>
<gml:pos srsDimension="3">493949.22 272050.31 295.55</gml:pos>
<gml:pos srsDimension="3">493947.34 272041.84 297.92</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_34">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_34_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493979.36 272055.95 297.84</gml:pos>
<gml:pos srsDimension="3">493976.88 272061.64 297.76</gml:pos>
<gml:pos srsDimension="3">493975.27 272060.92 297.03</gml:pos>
<gml:pos srsDimension="3">493976.82 272057.35 297.08</gml:pos>
<gml:pos srsDimension="3">493979.36 272055.95 297.84</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_35">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_35_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493978.96 272064.39 295.22</gml:pos>
<gml:pos srsDimension="3">493979.22 272063.79 295.43</gml:pos>
<gml:pos srsDimension="3">493969.37 272059.45 295.45</gml:pos>
<gml:pos srsDimension="3">493969.25 272059.73 295.35</gml:pos>
<gml:pos srsDimension="3">493966.70 272054.42 296.63</gml:pos>
<gml:pos srsDimension="3">493969.31 272051.48 297.87</gml:pos>
<gml:pos srsDimension="3">493984.18 272058.06 297.83</gml:pos>
<gml:pos srsDimension="3">493983.75 272062.41 296.45</gml:pos>
<gml:pos srsDimension="3">493978.96 272064.39 295.22</gml:pos>
</gml:LinearRing>
</gml:exterior>
<gml:interior>
<gml:LinearRing>
<gml:pos srsDimension="3">493979.36 272055.95 297.84</gml:pos>
<gml:pos srsDimension="3">493976.82 272057.35 297.08</gml:pos>
<gml:pos srsDimension="3">493975.27 272060.92 295.78</gml:pos>
<gml:pos srsDimension="3">493976.88 272061.64 295.78</gml:pos>
<gml:pos srsDimension="3">493978.57 272062.38 295.77</gml:pos>
<gml:pos srsDimension="3">493980.24 272058.86 297.07</gml:pos>
<gml:pos srsDimension="3">493979.36 272055.95 297.84</gml:pos>
</gml:LinearRing>
</gml:interior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_36">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_36_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493987.20 272056.99 295.52</gml:pos>
<gml:pos srsDimension="3">493985.24 272061.85 295.32</gml:pos>
<gml:pos srsDimension="3">493985.50 272062.17 294.96</gml:pos>
<gml:pos srsDimension="3">493983.34 272063.31 296.45</gml:pos>
<gml:pos srsDimension="3">493983.75 272062.41 296.45</gml:pos>
<gml:pos srsDimension="3">493984.18 272058.06 297.83</gml:pos>
<gml:pos srsDimension="3">493987.20 272056.99 295.52</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_37">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_37_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493967.06 272065.13 295.32</gml:pos>
<gml:pos srsDimension="3">493961.10 272066.43 296.75</gml:pos>
<gml:pos srsDimension="3">493961.72 272065.03 296.75</gml:pos>
<gml:pos srsDimension="3">493958.77 272062.26 297.84</gml:pos>
<gml:pos srsDimension="3">493961.64 272055.76 297.82</gml:pos>
<gml:pos srsDimension="3">493966.05 272055.88 296.64</gml:pos>
<gml:pos srsDimension="3">493966.70 272054.42 296.63</gml:pos>
<gml:pos srsDimension="3">493969.25 272059.73 295.35</gml:pos>
<gml:pos srsDimension="3">493966.90 272065.06 295.37</gml:pos>
<gml:pos srsDimension="3">493967.06 272065.13 295.32</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_38">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_38_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494012.39 272067.76 295.12</gml:pos>
<gml:pos srsDimension="3">494010.37 272072.25 295.02</gml:pos>
<gml:pos srsDimension="3">494009.84 272072.01 295.64</gml:pos>
<gml:pos srsDimension="3">494009.56 272072.63 295.63</gml:pos>
<gml:pos srsDimension="3">494008.93 272074.00 295.62</gml:pos>
<gml:pos srsDimension="3">494008.18 272075.56 295.64</gml:pos>
<gml:pos srsDimension="3">494008.97 272068.95 297.76</gml:pos>
<gml:pos srsDimension="3">494012.39 272067.76 295.12</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_39">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_39_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494007.86 272076.30 295.39</gml:pos>
<gml:pos srsDimension="3">493992.10 272069.30 295.46</gml:pos>
<gml:pos srsDimension="3">493991.92 272069.71 295.31</gml:pos>
<gml:pos srsDimension="3">493990.87 272066.36 296.19</gml:pos>
<gml:pos srsDimension="3">493990.44 272066.17 296.20</gml:pos>
<gml:pos srsDimension="3">493993.90 272062.29 297.82</gml:pos>
<gml:pos srsDimension="3">494008.97 272068.95 297.76</gml:pos>
<gml:pos srsDimension="3">494008.18 272075.56 295.64</gml:pos>
<gml:pos srsDimension="3">494007.86 272076.30 295.39</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_40">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_40_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493952.30 272069.15 295.72</gml:pos>
<gml:pos srsDimension="3">493935.94 272062.09 295.52</gml:pos>
<gml:pos srsDimension="3">493938.89 272060.95 297.88</gml:pos>
<gml:pos srsDimension="3">493951.22 272066.43 297.87</gml:pos>
<gml:pos srsDimension="3">493952.30 272069.15 295.72</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_41">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_41_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493945.97 272038.29 295.10</gml:pos>
<gml:pos srsDimension="3">493946.08 272038.03 294.79</gml:pos>
<gml:pos srsDimension="3">493962.69 272045.21 294.66</gml:pos>
<gml:pos srsDimension="3">493962.30 272046.18 295.75</gml:pos>
<gml:pos srsDimension="3">493959.62 272047.21 297.88</gml:pos>
<gml:pos srsDimension="3">493947.34 272041.84 297.92</gml:pos>
<gml:pos srsDimension="3">493945.97 272038.29 295.10</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_42">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_42_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493947.34 272041.84 297.92</gml:pos>
<gml:pos srsDimension="3">493949.22 272050.31 295.55</gml:pos>
<gml:pos srsDimension="3">493946.80 272055.99 295.50</gml:pos>
<gml:pos srsDimension="3">493947.22 272056.17 295.29</gml:pos>
<gml:pos srsDimension="3">493938.89 272060.95 297.88</gml:pos>
<gml:pos srsDimension="3">493947.34 272041.84 297.92</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_43">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_43_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494024.72 272096.10 294.90</gml:pos>
<gml:pos srsDimension="3">494003.82 272087.00 294.96</gml:pos>
<gml:pos srsDimension="3">494003.21 272086.71 294.96</gml:pos>
<gml:pos srsDimension="3">494003.51 272086.05 295.64</gml:pos>
<gml:pos srsDimension="3">494004.11 272084.74 296.98</gml:pos>
<gml:pos srsDimension="3">494023.72 272093.40 296.87</gml:pos>
<gml:pos srsDimension="3">494024.76 272096.01 294.99</gml:pos>
<gml:pos srsDimension="3">494024.72 272096.10 294.90</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_44">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522113-0066-62E0-E053-CA2BA8C0E403_RS_44_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494025.64 272089.06 296.94</gml:pos>
<gml:pos srsDimension="3">494023.72 272093.40 296.87</gml:pos>
<gml:pos srsDimension="3">494023.19 272087.99 297.49</gml:pos>
<gml:pos srsDimension="3">494025.64 272089.06 296.94</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</core:cityObjectMember>
<core:cityObjectMember>
<bldg:Building gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403">
<gen:stringAttribute name="buildingId">
<gen:value>2A522112-F975-62E0-E053-CA2BA8C0E403</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="przestNazw">
<gen:value>PL.PZGiK.238.BDOT10k</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="wersjaId">
<gen:value>2015-02-10T00:00:00</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="zrodloDach">
<gen:value>ALS_II</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="aktZrodla">
<gen:value>2011</gen:value>
</gen:stringAttribute>
<bldg:roofType>1040</bldg:roofType>
<bldg:lod2Solid>
<gml:Solid>
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_GS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_3_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_4_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_3_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_4_PG"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_GS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_GS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494082.46 272037.11 288.82</gml:pos>
<gml:pos srsDimension="3">494072.26 272032.06 288.82</gml:pos>
<gml:pos srsDimension="3">494056.48 272063.27 288.82</gml:pos>
<gml:pos srsDimension="3">494066.65 272068.41 288.82</gml:pos>
<gml:pos srsDimension="3">494082.46 272037.11 288.82</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494072.26 272032.06 288.82</gml:pos>
<gml:pos srsDimension="3">494082.46 272037.11 288.82</gml:pos>
<gml:pos srsDimension="3">494082.46 272037.11 302.29</gml:pos>
<gml:pos srsDimension="3">494082.38 272037.07 302.30</gml:pos>
<gml:pos srsDimension="3">494072.26 272032.06 302.28</gml:pos>
<gml:pos srsDimension="3">494072.26 272032.06 288.82</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494056.48 272063.27 288.82</gml:pos>
<gml:pos srsDimension="3">494072.26 272032.06 288.82</gml:pos>
<gml:pos srsDimension="3">494072.26 272032.06 302.28</gml:pos>
<gml:pos srsDimension="3">494072.21 272032.15 302.30</gml:pos>
<gml:pos srsDimension="3">494056.48 272063.27 302.20</gml:pos>
<gml:pos srsDimension="3">494056.48 272063.27 288.82</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494066.65 272068.41 288.82</gml:pos>
<gml:pos srsDimension="3">494056.48 272063.27 288.82</gml:pos>
<gml:pos srsDimension="3">494056.48 272063.27 302.20</gml:pos>
<gml:pos srsDimension="3">494056.63 272063.35 302.23</gml:pos>
<gml:pos srsDimension="3">494066.65 272068.41 302.21</gml:pos>
<gml:pos srsDimension="3">494066.65 272068.41 288.82</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_4">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_WS_4_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494082.46 272037.11 288.82</gml:pos>
<gml:pos srsDimension="3">494066.65 272068.41 288.82</gml:pos>
<gml:pos srsDimension="3">494066.65 272068.41 302.21</gml:pos>
<gml:pos srsDimension="3">494066.67 272068.37 302.22</gml:pos>
<gml:pos srsDimension="3">494082.46 272037.11 302.29</gml:pos>
<gml:pos srsDimension="3">494082.46 272037.11 288.82</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494066.67 272068.37 302.22</gml:pos>
<gml:pos srsDimension="3">494066.65 272068.41 302.21</gml:pos>
<gml:pos srsDimension="3">494056.63 272063.35 302.23</gml:pos>
<gml:pos srsDimension="3">494062.98 272062.25 303.02</gml:pos>
<gml:pos srsDimension="3">494066.67 272068.37 302.22</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494072.21 272032.15 302.30</gml:pos>
<gml:pos srsDimension="3">494072.26 272032.06 302.28</gml:pos>
<gml:pos srsDimension="3">494082.38 272037.07 302.30</gml:pos>
<gml:pos srsDimension="3">494075.18 272037.95 303.08</gml:pos>
<gml:pos srsDimension="3">494072.21 272032.15 302.30</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494082.46 272037.11 302.29</gml:pos>
<gml:pos srsDimension="3">494066.67 272068.37 302.22</gml:pos>
<gml:pos srsDimension="3">494062.98 272062.25 303.02</gml:pos>
<gml:pos srsDimension="3">494075.18 272037.95 303.08</gml:pos>
<gml:pos srsDimension="3">494082.38 272037.07 302.30</gml:pos>
<gml:pos srsDimension="3">494082.46 272037.11 302.29</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_4">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F975-62E0-E053-CA2BA8C0E403_RS_4_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494056.63 272063.35 302.23</gml:pos>
<gml:pos srsDimension="3">494056.48 272063.27 302.20</gml:pos>
<gml:pos srsDimension="3">494072.21 272032.15 302.30</gml:pos>
<gml:pos srsDimension="3">494075.18 272037.95 303.08</gml:pos>
<gml:pos srsDimension="3">494062.98 272062.25 303.02</gml:pos>
<gml:pos srsDimension="3">494056.63 272063.35 302.23</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</core:cityObjectMember>
<core:cityObjectMember>
<bldg:Building gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403">
<gen:stringAttribute name="buildingId">
<gen:value>2A522112-F816-62E0-E053-CA2BA8C0E403</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="przestNazw">
<gen:value>PL.PZGiK.238.BDOT10k</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="wersjaId">
<gen:value>2015-02-10T00:00:00</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="zrodloDach">
<gen:value>ALS_II</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="aktZrodla">
<gen:value>2011</gen:value>
</gen:stringAttribute>
<bldg:roofType>1130</bldg:roofType>
<bldg:lod2Solid>
<gml:Solid>
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_GS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_3_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_4_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_5_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_6_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_7_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_8_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_9_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_10_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_11_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_12_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_13_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_RS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_RS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_RS_3_PG"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_GS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_GS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494154.97 271966.99 289.02</gml:pos>
<gml:pos srsDimension="3">494155.38 271966.19 289.02</gml:pos>
<gml:pos srsDimension="3">494160.16 271956.96 289.02</gml:pos>
<gml:pos srsDimension="3">494158.88 271956.33 289.02</gml:pos>
<gml:pos srsDimension="3">494158.35 271956.06 289.02</gml:pos>
<gml:pos srsDimension="3">494155.56 271954.67 289.02</gml:pos>
<gml:pos srsDimension="3">494155.02 271954.39 289.02</gml:pos>
<gml:pos srsDimension="3">494154.69 271954.23 289.02</gml:pos>
<gml:pos srsDimension="3">494154.28 271955.03 289.02</gml:pos>
<gml:pos srsDimension="3">494154.04 271955.53 289.02</gml:pos>
<gml:pos srsDimension="3">494149.66 271964.34 289.02</gml:pos>
<gml:pos srsDimension="3">494152.31 271965.66 289.02</gml:pos>
<gml:pos srsDimension="3">494154.97 271966.99 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494155.38 271966.19 289.02</gml:pos>
<gml:pos srsDimension="3">494154.97 271966.99 289.02</gml:pos>
<gml:pos srsDimension="3">494154.97 271966.99 297.05</gml:pos>
<gml:pos srsDimension="3">494155.38 271966.19 297.16</gml:pos>
<gml:pos srsDimension="3">494155.38 271966.19 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494160.16 271956.96 289.02</gml:pos>
<gml:pos srsDimension="3">494155.38 271966.19 289.02</gml:pos>
<gml:pos srsDimension="3">494155.38 271966.19 297.16</gml:pos>
<gml:pos srsDimension="3">494157.10 271962.87 297.64</gml:pos>
<gml:pos srsDimension="3">494157.10 271962.87 300.04</gml:pos>
<gml:pos srsDimension="3">494158.88 271959.43 297.01</gml:pos>
<gml:pos srsDimension="3">494160.16 271956.96 296.78</gml:pos>
<gml:pos srsDimension="3">494160.16 271956.96 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494158.88 271956.33 289.02</gml:pos>
<gml:pos srsDimension="3">494160.16 271956.96 289.02</gml:pos>
<gml:pos srsDimension="3">494160.16 271956.96 296.78</gml:pos>
<gml:pos srsDimension="3">494158.88 271956.33 296.77</gml:pos>
<gml:pos srsDimension="3">494158.88 271956.33 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_4">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_4_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494158.35 271956.06 289.02</gml:pos>
<gml:pos srsDimension="3">494158.88 271956.33 289.02</gml:pos>
<gml:pos srsDimension="3">494158.88 271956.33 296.77</gml:pos>
<gml:pos srsDimension="3">494158.35 271956.06 296.77</gml:pos>
<gml:pos srsDimension="3">494158.35 271956.06 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_5">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_5_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494155.56 271954.67 289.02</gml:pos>
<gml:pos srsDimension="3">494158.35 271956.06 289.02</gml:pos>
<gml:pos srsDimension="3">494158.35 271956.06 296.77</gml:pos>
<gml:pos srsDimension="3">494155.56 271954.67 296.77</gml:pos>
<gml:pos srsDimension="3">494155.56 271954.67 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_6">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_6_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494155.02 271954.39 289.02</gml:pos>
<gml:pos srsDimension="3">494155.56 271954.67 289.02</gml:pos>
<gml:pos srsDimension="3">494155.56 271954.67 296.77</gml:pos>
<gml:pos srsDimension="3">494155.02 271954.39 296.77</gml:pos>
<gml:pos srsDimension="3">494155.02 271954.39 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_7">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_7_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494154.69 271954.23 289.02</gml:pos>
<gml:pos srsDimension="3">494155.02 271954.39 289.02</gml:pos>
<gml:pos srsDimension="3">494155.02 271954.39 296.77</gml:pos>
<gml:pos srsDimension="3">494154.69 271954.23 296.77</gml:pos>
<gml:pos srsDimension="3">494154.69 271954.23 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_8">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_8_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494154.28 271955.03 289.02</gml:pos>
<gml:pos srsDimension="3">494154.69 271954.23 289.02</gml:pos>
<gml:pos srsDimension="3">494154.69 271954.23 296.77</gml:pos>
<gml:pos srsDimension="3">494154.28 271955.03 296.84</gml:pos>
<gml:pos srsDimension="3">494154.28 271955.03 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_9">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_9_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494154.04 271955.53 289.02</gml:pos>
<gml:pos srsDimension="3">494154.28 271955.03 289.02</gml:pos>
<gml:pos srsDimension="3">494154.28 271955.03 296.84</gml:pos>
<gml:pos srsDimension="3">494154.04 271955.53 296.89</gml:pos>
<gml:pos srsDimension="3">494154.04 271955.53 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_10">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_10_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494149.66 271964.34 289.02</gml:pos>
<gml:pos srsDimension="3">494154.04 271955.53 289.02</gml:pos>
<gml:pos srsDimension="3">494154.04 271955.53 296.89</gml:pos>
<gml:pos srsDimension="3">494153.53 271956.56 296.98</gml:pos>
<gml:pos srsDimension="3">494151.69 271960.26 300.21</gml:pos>
<gml:pos srsDimension="3">494151.69 271960.26 297.67</gml:pos>
<gml:pos srsDimension="3">494149.66 271964.34 297.09</gml:pos>
<gml:pos srsDimension="3">494149.66 271964.34 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_11">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_11_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494152.31 271965.66 289.02</gml:pos>
<gml:pos srsDimension="3">494149.66 271964.34 289.02</gml:pos>
<gml:pos srsDimension="3">494149.66 271964.34 297.09</gml:pos>
<gml:pos srsDimension="3">494152.31 271965.66 297.07</gml:pos>
<gml:pos srsDimension="3">494152.31 271965.66 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_12">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_12_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494154.97 271966.99 289.02</gml:pos>
<gml:pos srsDimension="3">494152.31 271965.66 289.02</gml:pos>
<gml:pos srsDimension="3">494152.31 271965.66 297.07</gml:pos>
<gml:pos srsDimension="3">494154.97 271966.99 297.05</gml:pos>
<gml:pos srsDimension="3">494154.97 271966.99 289.02</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_13">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_WS_13_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494157.10 271962.87 297.64</gml:pos>
<gml:pos srsDimension="3">494151.69 271960.26 297.67</gml:pos>
<gml:pos srsDimension="3">494151.69 271960.26 300.21</gml:pos>
<gml:pos srsDimension="3">494157.10 271962.87 300.04</gml:pos>
<gml:pos srsDimension="3">494157.10 271962.87 297.64</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_RS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_RS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494153.53 271956.56 296.98</gml:pos>
<gml:pos srsDimension="3">494154.04 271955.53 296.89</gml:pos>
<gml:pos srsDimension="3">494154.28 271955.03 296.84</gml:pos>
<gml:pos srsDimension="3">494154.69 271954.23 296.77</gml:pos>
<gml:pos srsDimension="3">494155.02 271954.39 296.77</gml:pos>
<gml:pos srsDimension="3">494155.56 271954.67 296.77</gml:pos>
<gml:pos srsDimension="3">494158.35 271956.06 296.77</gml:pos>
<gml:pos srsDimension="3">494158.88 271956.33 296.77</gml:pos>
<gml:pos srsDimension="3">494160.16 271956.96 296.78</gml:pos>
<gml:pos srsDimension="3">494158.88 271959.43 297.01</gml:pos>
<gml:pos srsDimension="3">494153.53 271956.56 296.98</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_RS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_RS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494151.69 271960.26 300.21</gml:pos>
<gml:pos srsDimension="3">494153.53 271956.56 296.98</gml:pos>
<gml:pos srsDimension="3">494158.88 271959.43 297.01</gml:pos>
<gml:pos srsDimension="3">494157.10 271962.87 300.04</gml:pos>
<gml:pos srsDimension="3">494151.69 271960.26 300.21</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_RS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F816-62E0-E053-CA2BA8C0E403_RS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494157.10 271962.87 297.64</gml:pos>
<gml:pos srsDimension="3">494155.38 271966.19 297.16</gml:pos>
<gml:pos srsDimension="3">494154.97 271966.99 297.05</gml:pos>
<gml:pos srsDimension="3">494152.31 271965.66 297.07</gml:pos>
<gml:pos srsDimension="3">494149.66 271964.34 297.09</gml:pos>
<gml:pos srsDimension="3">494151.69 271960.26 297.67</gml:pos>
<gml:pos srsDimension="3">494157.10 271962.87 297.64</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</core:cityObjectMember>
<core:cityObjectMember>
<bldg:Building gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403">
<gen:stringAttribute name="buildingId">
<gen:value>2A522112-F8DE-62E0-E053-CA2BA8C0E403</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="przestNazw">
<gen:value>PL.PZGiK.238.BDOT10k</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="wersjaId">
<gen:value>2015-02-10T00:00:00</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="zrodloDach">
<gen:value>ALS_II</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="aktZrodla">
<gen:value>2011</gen:value>
</gen:stringAttribute>
<bldg:roofType>1130</bldg:roofType>
<bldg:lod2Solid>
<gml:Solid>
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_GS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_3_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_4_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_5_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_6_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_7_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_8_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_9_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_10_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_11_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_12_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_RS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_RS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_RS_3_PG"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_GS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_GS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494091.25 271940.42 290.89</gml:pos>
<gml:pos srsDimension="3">494091.69 271939.53 290.89</gml:pos>
<gml:pos srsDimension="3">494096.04 271930.72 290.89</gml:pos>
<gml:pos srsDimension="3">494094.59 271929.99 290.89</gml:pos>
<gml:pos srsDimension="3">494094.06 271929.73 290.89</gml:pos>
<gml:pos srsDimension="3">494091.26 271928.32 290.89</gml:pos>
<gml:pos srsDimension="3">494090.92 271928.14 290.89</gml:pos>
<gml:pos srsDimension="3">494090.72 271928.04 290.89</gml:pos>
<gml:pos srsDimension="3">494086.27 271936.83 290.89</gml:pos>
<gml:pos srsDimension="3">494085.84 271937.69 290.89</gml:pos>
<gml:pos srsDimension="3">494088.59 271939.08 290.89</gml:pos>
<gml:pos srsDimension="3">494091.25 271940.42 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494091.69 271939.53 290.89</gml:pos>
<gml:pos srsDimension="3">494091.25 271940.42 290.89</gml:pos>
<gml:pos srsDimension="3">494091.25 271940.42 299.04</gml:pos>
<gml:pos srsDimension="3">494091.69 271939.53 299.15</gml:pos>
<gml:pos srsDimension="3">494091.69 271939.53 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494096.04 271930.72 290.89</gml:pos>
<gml:pos srsDimension="3">494091.69 271939.53 290.89</gml:pos>
<gml:pos srsDimension="3">494091.69 271939.53 299.15</gml:pos>
<gml:pos srsDimension="3">494093.31 271936.24 299.58</gml:pos>
<gml:pos srsDimension="3">494093.31 271936.24 301.94</gml:pos>
<gml:pos srsDimension="3">494095.13 271932.56 298.71</gml:pos>
<gml:pos srsDimension="3">494096.04 271930.72 298.44</gml:pos>
<gml:pos srsDimension="3">494096.04 271930.72 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494094.59 271929.99 290.89</gml:pos>
<gml:pos srsDimension="3">494096.04 271930.72 290.89</gml:pos>
<gml:pos srsDimension="3">494096.04 271930.72 298.44</gml:pos>
<gml:pos srsDimension="3">494094.59 271929.99 298.45</gml:pos>
<gml:pos srsDimension="3">494094.59 271929.99 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_4">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_4_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494094.06 271929.73 290.89</gml:pos>
<gml:pos srsDimension="3">494094.59 271929.99 290.89</gml:pos>
<gml:pos srsDimension="3">494094.59 271929.99 298.45</gml:pos>
<gml:pos srsDimension="3">494094.06 271929.73 298.45</gml:pos>
<gml:pos srsDimension="3">494094.06 271929.73 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_5">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_5_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494091.26 271928.32 290.89</gml:pos>
<gml:pos srsDimension="3">494094.06 271929.73 290.89</gml:pos>
<gml:pos srsDimension="3">494094.06 271929.73 298.45</gml:pos>
<gml:pos srsDimension="3">494091.26 271928.32 298.46</gml:pos>
<gml:pos srsDimension="3">494091.26 271928.32 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_6">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_6_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494090.92 271928.14 290.89</gml:pos>
<gml:pos srsDimension="3">494091.26 271928.32 290.89</gml:pos>
<gml:pos srsDimension="3">494091.26 271928.32 298.46</gml:pos>
<gml:pos srsDimension="3">494090.92 271928.14 298.46</gml:pos>
<gml:pos srsDimension="3">494090.92 271928.14 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_7">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_7_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494090.72 271928.04 290.89</gml:pos>
<gml:pos srsDimension="3">494090.92 271928.14 290.89</gml:pos>
<gml:pos srsDimension="3">494090.92 271928.14 298.46</gml:pos>
<gml:pos srsDimension="3">494090.72 271928.04 298.46</gml:pos>
<gml:pos srsDimension="3">494090.72 271928.04 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_8">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_8_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494086.27 271936.83 290.89</gml:pos>
<gml:pos srsDimension="3">494090.72 271928.04 290.89</gml:pos>
<gml:pos srsDimension="3">494090.72 271928.04 298.46</gml:pos>
<gml:pos srsDimension="3">494089.76 271929.93 298.74</gml:pos>
<gml:pos srsDimension="3">494087.84 271933.72 302.08</gml:pos>
<gml:pos srsDimension="3">494087.84 271933.72 299.58</gml:pos>
<gml:pos srsDimension="3">494086.27 271936.83 299.18</gml:pos>
<gml:pos srsDimension="3">494086.27 271936.83 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_9">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_9_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494085.84 271937.69 290.89</gml:pos>
<gml:pos srsDimension="3">494086.27 271936.83 290.89</gml:pos>
<gml:pos srsDimension="3">494086.27 271936.83 299.18</gml:pos>
<gml:pos srsDimension="3">494085.84 271937.69 299.06</gml:pos>
<gml:pos srsDimension="3">494085.84 271937.69 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_10">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_10_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494088.59 271939.08 290.89</gml:pos>
<gml:pos srsDimension="3">494085.84 271937.69 290.89</gml:pos>
<gml:pos srsDimension="3">494085.84 271937.69 299.06</gml:pos>
<gml:pos srsDimension="3">494088.59 271939.08 299.05</gml:pos>
<gml:pos srsDimension="3">494088.59 271939.08 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_11">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_11_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494091.25 271940.42 290.89</gml:pos>
<gml:pos srsDimension="3">494088.59 271939.08 290.89</gml:pos>
<gml:pos srsDimension="3">494088.59 271939.08 299.05</gml:pos>
<gml:pos srsDimension="3">494091.25 271940.42 299.04</gml:pos>
<gml:pos srsDimension="3">494091.25 271940.42 290.89</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_12">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_WS_12_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494093.31 271936.24 299.58</gml:pos>
<gml:pos srsDimension="3">494087.84 271933.72 299.58</gml:pos>
<gml:pos srsDimension="3">494087.84 271933.72 302.08</gml:pos>
<gml:pos srsDimension="3">494093.31 271936.24 301.94</gml:pos>
<gml:pos srsDimension="3">494093.31 271936.24 299.58</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_RS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_RS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494093.31 271936.24 299.58</gml:pos>
<gml:pos srsDimension="3">494091.69 271939.53 299.15</gml:pos>
<gml:pos srsDimension="3">494091.25 271940.42 299.04</gml:pos>
<gml:pos srsDimension="3">494088.59 271939.08 299.05</gml:pos>
<gml:pos srsDimension="3">494085.84 271937.69 299.06</gml:pos>
<gml:pos srsDimension="3">494086.27 271936.83 299.18</gml:pos>
<gml:pos srsDimension="3">494087.84 271933.72 299.58</gml:pos>
<gml:pos srsDimension="3">494093.31 271936.24 299.58</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_RS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_RS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494093.31 271936.24 301.94</gml:pos>
<gml:pos srsDimension="3">494087.84 271933.72 302.08</gml:pos>
<gml:pos srsDimension="3">494089.76 271929.93 298.74</gml:pos>
<gml:pos srsDimension="3">494095.13 271932.56 298.71</gml:pos>
<gml:pos srsDimension="3">494093.31 271936.24 301.94</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_RS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F8DE-62E0-E053-CA2BA8C0E403_RS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">494089.76 271929.93 298.74</gml:pos>
<gml:pos srsDimension="3">494090.72 271928.04 298.46</gml:pos>
<gml:pos srsDimension="3">494090.92 271928.14 298.46</gml:pos>
<gml:pos srsDimension="3">494091.26 271928.32 298.46</gml:pos>
<gml:pos srsDimension="3">494094.06 271929.73 298.45</gml:pos>
<gml:pos srsDimension="3">494094.59 271929.99 298.45</gml:pos>
<gml:pos srsDimension="3">494096.04 271930.72 298.44</gml:pos>
<gml:pos srsDimension="3">494095.13 271932.56 298.71</gml:pos>
<gml:pos srsDimension="3">494089.76 271929.93 298.74</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</core:cityObjectMember>
<core:cityObjectMember>
<bldg:Building gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403">
<gen:stringAttribute name="buildingId">
<gen:value>2A522112-F96B-62E0-E053-CA2BA8C0E403</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="przestNazw">
<gen:value>PL.PZGiK.238.BDOT10k</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="wersjaId">
<gen:value>2015-02-10T00:00:00</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="zrodloDach">
<gen:value>ALS_II</gen:value>
</gen:stringAttribute>
<gen:stringAttribute name="aktZrodla">
<gen:value>2011</gen:value>
</gen:stringAttribute>
<bldg:roofType>1000</bldg:roofType>
<bldg:lod2Solid>
<gml:Solid>
<gml:exterior>
<gml:CompositeSurface>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_GS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_1_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_2_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_3_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_4_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_5_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_6_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_7_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_8_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_9_PG"/>
<gml:surfaceMember xlink:href="#ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_RS_1_PG"/>
</gml:CompositeSurface>
</gml:exterior>
</gml:Solid>
</bldg:lod2Solid>
<bldg:boundedBy>
<bldg:GroundSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_GS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_GS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493719.34 271756.43 301.07</gml:pos>
<gml:pos srsDimension="3">493721.69 271752.60 301.07</gml:pos>
<gml:pos srsDimension="3">493722.59 271750.74 301.07</gml:pos>
<gml:pos srsDimension="3">493723.82 271748.60 301.07</gml:pos>
<gml:pos srsDimension="3">493724.10 271748.10 301.07</gml:pos>
<gml:pos srsDimension="3">493724.15 271747.97 301.07</gml:pos>
<gml:pos srsDimension="3">493718.19 271745.47 301.07</gml:pos>
<gml:pos srsDimension="3">493714.37 271754.15 301.07</gml:pos>
<gml:pos srsDimension="3">493715.35 271754.62 301.07</gml:pos>
<gml:pos srsDimension="3">493719.34 271756.43 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:GroundSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493721.69 271752.60 301.07</gml:pos>
<gml:pos srsDimension="3">493719.34 271756.43 301.07</gml:pos>
<gml:pos srsDimension="3">493719.34 271756.43 309.40</gml:pos>
<gml:pos srsDimension="3">493721.69 271752.60 309.42</gml:pos>
<gml:pos srsDimension="3">493721.69 271752.60 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_2">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_2_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493722.59 271750.74 301.07</gml:pos>
<gml:pos srsDimension="3">493721.69 271752.60 301.07</gml:pos>
<gml:pos srsDimension="3">493721.69 271752.60 309.42</gml:pos>
<gml:pos srsDimension="3">493722.59 271750.74 309.40</gml:pos>
<gml:pos srsDimension="3">493722.59 271750.74 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_3">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_3_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493723.82 271748.60 301.07</gml:pos>
<gml:pos srsDimension="3">493722.59 271750.74 301.07</gml:pos>
<gml:pos srsDimension="3">493722.59 271750.74 309.40</gml:pos>
<gml:pos srsDimension="3">493723.82 271748.60 309.40</gml:pos>
<gml:pos srsDimension="3">493723.82 271748.60 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_4">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_4_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493724.10 271748.10 301.07</gml:pos>
<gml:pos srsDimension="3">493723.82 271748.60 301.07</gml:pos>
<gml:pos srsDimension="3">493723.82 271748.60 309.40</gml:pos>
<gml:pos srsDimension="3">493724.10 271748.10 309.39</gml:pos>
<gml:pos srsDimension="3">493724.10 271748.10 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_5">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_5_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493724.15 271747.97 301.07</gml:pos>
<gml:pos srsDimension="3">493724.10 271748.10 301.07</gml:pos>
<gml:pos srsDimension="3">493724.10 271748.10 309.39</gml:pos>
<gml:pos srsDimension="3">493724.15 271747.97 309.39</gml:pos>
<gml:pos srsDimension="3">493724.15 271747.97 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_6">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_6_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493718.19 271745.47 301.07</gml:pos>
<gml:pos srsDimension="3">493724.15 271747.97 301.07</gml:pos>
<gml:pos srsDimension="3">493724.15 271747.97 309.39</gml:pos>
<gml:pos srsDimension="3">493718.19 271745.47 308.38</gml:pos>
<gml:pos srsDimension="3">493718.19 271745.47 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_7">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_7_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493714.37 271754.15 301.07</gml:pos>
<gml:pos srsDimension="3">493718.19 271745.47 301.07</gml:pos>
<gml:pos srsDimension="3">493718.19 271745.47 308.38</gml:pos>
<gml:pos srsDimension="3">493714.37 271754.15 308.54</gml:pos>
<gml:pos srsDimension="3">493714.37 271754.15 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_8">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_8_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493715.35 271754.62 301.07</gml:pos>
<gml:pos srsDimension="3">493714.37 271754.15 301.07</gml:pos>
<gml:pos srsDimension="3">493714.37 271754.15 308.54</gml:pos>
<gml:pos srsDimension="3">493715.35 271754.62 308.71</gml:pos>
<gml:pos srsDimension="3">493715.35 271754.62 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:WallSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_9">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_WS_9_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493719.34 271756.43 301.07</gml:pos>
<gml:pos srsDimension="3">493715.35 271754.62 301.07</gml:pos>
<gml:pos srsDimension="3">493715.35 271754.62 308.71</gml:pos>
<gml:pos srsDimension="3">493719.34 271756.43 309.40</gml:pos>
<gml:pos srsDimension="3">493719.34 271756.43 301.07</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:WallSurface>
</bldg:boundedBy>
<bldg:boundedBy>
<bldg:RoofSurface gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_RS_1">
<bldg:lod2MultiSurface>
<gml:MultiSurface>
<gml:surfaceMember>
<gml:Polygon gml:id="ID-2476-2A522112-F96B-62E0-E053-CA2BA8C0E403_RS_1_PG">
<gml:exterior>
<gml:LinearRing>
<gml:pos srsDimension="3">493719.34 271756.43 309.40</gml:pos>
<gml:pos srsDimension="3">493715.35 271754.62 308.71</gml:pos>
<gml:pos srsDimension="3">493714.37 271754.15 308.54</gml:pos>
<gml:pos srsDimension="3">493718.19 271745.47 308.38</gml:pos>
<gml:pos srsDimension="3">493724.15 271747.97 309.39</gml:pos>
<gml:pos srsDimension="3">493724.10 271748.10 309.39</gml:pos>
<gml:pos srsDimension="3">493723.82 271748.60 309.40</gml:pos>
<gml:pos srsDimension="3">493722.59 271750.74 309.40</gml:pos>
<gml:pos srsDimension="3">493721.69 271752.60 309.42</gml:pos>
<gml:pos srsDimension="3">493719.34 271756.43 309.40</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</bldg:lod2MultiSurface>
</bldg:RoofSurface>
</bldg:boundedBy>
</bldg:Building>
</core:cityObjectMember>
</core:CityModel>
